# Script 0: Procesamiento y limpieza de datos
# Corresponde a la sección 5 (Datos y metodología). Carga y limpia el archivo de respuestas, renombra variables, construye el Índice de Severidad Clínica (ISC) y estima el costo por accidente según el Nomenclador del GCBA. Genera el dataset analítico utilizado por todos los scripts siguientes.

# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Script: Limpieza, ISC y costos por accidente
# Fuente aranceles: Nomenclador MS-GCABA - Vigente 15 Abril 2026
# =============================================================================
library(tidyverse)
library(janitor)
# =============================================================================
# 0. ARANCELES DE REFERENCIA (Nomenclador MS-GCABA, Abril 2026)
# =============================================================================
ARANCEL_GUARDIA        <- 132226   # GUAR.02: observación en guardia
ARANCEL_DIA_INTERNAC   <- 444959   # INC.01: día clínico
ARANCEL_CIRUGIA_OST    <- 1473726  # OYT.04.10: osteosíntesis miembro sup/inf
ARANCEL_CIRUGIA_ART    <- 654955   # OYT.09.01: artroscopia (luxaciones)
ARANCEL_CIRUGIA_DISC   <- 2120812  # OYT.05.04: hernia discal / cadera
ARANCEL_RX             <- 16637    # IMA.20: radiografía simple
ARANCEL_ECOGRAFIA      <- 22183    # IMA.12: ecografía simple
ARANCEL_TAC            <- 159121   # IMA.22: tomografía computada
ARANCEL_RMN            <- 190602   # IMA.21: resonancia magnética
ARANCEL_SESION_REHAB   <- 21610    # REHA.06: kinesioterapia por sesión
FACTOR_PUBLICO         <- 1.0      # nomenclador GCBA
FACTOR_PRIVADO         <- 1.0      # mismo arancel base GCBA (ver análisis de sensibilidad en tesina)
N_ACC <- 7
# =============================================================================
# 1. CARGA
# =============================================================================
datos_raw <- read_csv("respuestas_limpio.csv", show_col_types = FALSE)
datos <- clean_names(datos_raw)
# Nota: clean_names() resuelve columnas duplicadas agregando el número de columna.
# lesion_principal queda: _18 (acc1), _31 (acc2), _2 (acc3), _3..._6 (acc4-7)
# =============================================================================
# 2. RENOMBRAR
# =============================================================================
datos <- datos %>% rename(
  edad                 = edad_indicar_numero,
  region               = region_donde_mas_practicas_la_disciplina,
  otro_pais            = si_selecciono_otro_pais_especifique_cual,
  disciplina_principal = cual_es_tu_disciplina_principal_de_ciclismo,
  otras_disciplinas    = practicas_otras_disciplinas_ademas_de_la_principal,
  nivel                = como_describirias_tu_nivel_en_la_disciplina_principal,
  anios_practica       = hace_cuantos_anos_practicas_la_disciplina_principal,
  meses_anio           = cuantos_meses_al_ano_practicas_la_disciplina_principal,
  dias_semana          = cuantos_dias_por_semana_practicas_la_disciplina_principal_en_esos_meses,
  horas_dia            = cuantas_horas_dedicas_a_la_disciplina_principal_en_un_dia_tipico_de_salida,
  tendencia_exposicion = comparada_con_tus_primeros_anos_de_practica_como_fue_tu_intensidad_frecuencia_horas_a_lo_largo_del_tiempo,
  compite              = participas_en_competencias,
  competencias_anio    = cuantas_competencias_en_promedio_por_ano_indicar_numero,
  tuvo_lesiones        = tuviste_lesiones_que_requerian_asistencia_medica_en_los_ultimos_24_meses,
  n_acc_24m            = cuantas_lesiones_que_requerian_asistencia_medica_tuviste_en_los_ultimos_24_meses_indicar_numero,
  cobertura            = tenes_cobertura_medica,
  cobertura_deportes   = tu_cobertura_incluye_accidentes_deportivos,
  contrataria_seguro   = contratarias_un_seguro_deportivo_especifico_para_ciclismo,
  wtp_monto            = cuanto_pagarias_usd_mes_por_este_seguro_deportivo,
  tipo_cobertura       = que_tipo_de_cobertura_preferirias
)
# Accidente 1
datos <- datos %>% rename(
  acc1_disc          = disciplina,
  acc1_lesion        = lesion_principal_18,
  acc1_parte         = parte_del_cuerpo,
  acc1_contexto      = contexto,
  acc1_guardia       = requirio_guardia_o_emergencia,
  acc1_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias,
  acc1_cirugia       = requirio_cirugia,
  acc1_imagen        = estudios_de_imagen,
  acc1_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron,
  acc1_evacuacion    = evacuacion,
  acc1_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc,
  acc1_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional,
  acc1_lugar         = donde_recibiste_atencion_medica_por_este_accidente
)
# Accidente 2
datos <- datos %>% rename(
  acc2_tiene         = tenes_un_segundo_accidente_para_registrar,
  acc2_disc          = disciplina_2,
  acc2_lesion        = lesion_principal_31,
  acc2_parte         = parte_del_cuerpo_2,
  acc2_contexto      = contexto_2,
  acc2_guardia       = requirio_guardia_o_emergencia_2,
  acc2_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_2,
  acc2_cirugia       = requirio_cirugia_2,
  acc2_imagen        = estudios_de_imagen_2,
  acc2_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_2,
  acc2_evacuacion    = evacuacion_2,
  acc2_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_2,
  acc2_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_2,
  acc2_lugar         = donde_recibiste_atencion_medica_por_este_accidente_2
)
# Accidente 3
datos <- datos %>% rename(
  acc3_tiene         = tenes_un_tercer_accidente_para_registrar,
  acc3_disc          = disciplina_3,
  acc3_lesion        = lesion_principal_2,
  acc3_parte         = parte_del_cuerpo_3,
  acc3_contexto      = contexto_3,
  acc3_guardia       = requirio_guardia_o_emergencia_3,
  acc3_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_3,
  acc3_cirugia       = requirio_cirugia_3,
  acc3_imagen        = estudios_de_imagen_3,
  acc3_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_3,
  acc3_evacuacion    = evacuacion_3,
  acc3_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_3,
  acc3_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_3,
  acc3_lugar         = donde_recibiste_atencion_medica_por_este_accidente_3
)
# Accidente 4
datos <- datos %>% rename(
  acc4_tiene         = tenes_un_cuarto_accidente_para_registrar,
  acc4_disc          = disciplina_4,
  acc4_lesion        = lesion_principal_3,
  acc4_parte         = parte_del_cuerpo_4,
  acc4_contexto      = contexto_4,
  acc4_guardia       = requirio_guardia_o_emergencia_4,
  acc4_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_4,
  acc4_cirugia       = requirio_cirugia_4,
  acc4_imagen        = estudios_de_imagen_4,
  acc4_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_4,
  acc4_evacuacion    = evacuacion_4,
  acc4_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_4,
  acc4_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_4,
  acc4_lugar         = donde_recibiste_atencion_medica_por_este_accidente_4
)
# Accidente 5
datos <- datos %>% rename(
  acc5_tiene         = tenes_un_quinto_accidente_para_registrar,
  acc5_disc          = disciplina_5,
  acc5_lesion        = lesion_principal_4,
  acc5_parte         = parte_del_cuerpo_5,
  acc5_contexto      = contexto_5,
  acc5_guardia       = requirio_guardia_o_emergencia_5,
  acc5_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_5,
  acc5_cirugia       = requirio_cirugia_5,
  acc5_imagen        = estudios_de_imagen_5,
  acc5_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_5,
  acc5_evacuacion    = evacuacion_5,
  acc5_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_5,
  acc5_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_5,
  acc5_lugar         = donde_recibiste_atencion_medica_por_este_accidente_5
)
# Accidente 6
datos <- datos %>% rename(
  acc6_tiene         = tenes_un_sexto_accidente_para_registrar,
  acc6_disc          = disciplina_6,
  acc6_lesion        = lesion_principal_5,
  acc6_parte         = parte_del_cuerpo_6,
  acc6_contexto      = contexto_6,
  acc6_guardia       = requirio_guardia_o_emergencia_6,
  acc6_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_6,
  acc6_cirugia       = requirio_cirugia_6,
  acc6_imagen        = estudios_de_imagen_6,
  acc6_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_6,
  acc6_evacuacion    = evacuacion_6,
  acc6_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_6,
  acc6_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_6,
  acc6_lugar         = donde_recibiste_atencion_medica_por_este_accidente_6
)
# Accidente 7
datos <- datos %>% rename(
  acc7_tiene         = tenes_un_septimo_accidente_para_registrar,
  acc7_disc          = disciplina_7,
  acc7_lesion        = lesion_principal_6,
  acc7_parte         = parte_del_cuerpo_7,
  acc7_contexto      = contexto_7,
  acc7_guardia       = requirio_guardia_o_emergencia_7,
  acc7_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_7,
  acc7_cirugia       = requirio_cirugia_7,
  acc7_imagen        = estudios_de_imagen_7,
  acc7_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_7,
  acc7_evacuacion    = evacuacion_7,
  acc7_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_7,
  acc7_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_7,
  acc7_lugar         = donde_recibiste_atencion_medica_por_este_accidente_7
)
# Eliminar columnas fantasma
datos <- datos %>% dplyr::select(-matches("^parte_del_cuerpo_(8|9|10|11|12|13)$"))
# =============================================================================
# 3. LIMPIEZA
# =============================================================================
datos <- datos %>%
  mutate(fecha = Sys.Date())
rehab_cols    <- paste0("acc", 1:N_ACC, "_rehab")
dias_cols     <- paste0("acc", 1:N_ACC, "_dias_perdidos")
internac_cols <- paste0("acc", 1:N_ACC, "_internacion")
datos <- datos %>%

mutate(across(all_of(rehab_cols),    ~ replace_na(as.numeric(.x), 0))) %>%
  mutate(across(all_of(dias_cols),     ~ replace_na(as.numeric(.x), 0))) %>%
  mutate(across(all_of(internac_cols), ~ replace_na(as.numeric(.x), 0))) %>%

mutate(n_acc_24m = if_else(tuvo_lesiones == "No", 0, as.numeric(n_acc_24m)))
# =============================================================================
# 4. FILTROS DE MUESTRA
# =============================================================================
# 1. Solo Argentina
# 2. Solo DH o Enduro como disciplina principal O secundaria
# 3. n_acc_24m <= 7 (el formulario solo captura hasta 7 accidentes;
#    quien declara 9 probablemente incluyó accidentes sin atención médica
#    o errores de tipeo — se documenta como criterio de exclusión)
datos <- datos %>%
  filter(region != "Otro país") %>%
  filter(
    str_detect(disciplina_principal, "Downhill|DH|Enduro") |
      str_detect(otras_disciplinas,    "Downhill|DH|Enduro")

) %>%
  filter(is.na(n_acc_24m) | n_acc_24m <= 7)
cat("Respondentes tras filtros:", nrow(datos), "\n")
# =============================================================================
# 5. EXPOSICIÓN (ventana 24 meses)
# =============================================================================
datos <- datos %>%
  mutate(
    # Para menos de 1 año: meses calculados desde anios_practica directamente
    # Para el resto: usa meses_anio reportado
    meses_efectivos  = if_else(anios_practica < 1,
                               anios_practica * 12,
                               as.numeric(meses_anio)),
    # Ventana máxima: 2 años (24 meses)
    anos_exposicion  = pmin(anios_practica, 2),
    # tendencia_exposicion entra como covariable en el GLM
    exposicion_horas = anos_exposicion * (meses_efectivos / 12) * dias_semana * horas_dia * 52.18
  )
# Excluir outliers de exposición (>5000h en 24m = implausible)
# Criterio documentado en tesina como criterio de calidad de datos
n_antes <- nrow(datos)
datos <- datos %>% filter(exposicion_horas <= 5000)
cat("Outliers de exposicion excluidos:", n_antes - nrow(datos), "\n")
cat("Respondentes finales:", nrow(datos), "\n")
# =============================================================================
# 6. FUNCIONES: COSTO E ISC
# =============================================================================
factor_lugar <- function(lugar) {

case_when(
    is.na(lugar)                                 ~ FACTOR_PUBLICO,

str_detect(lugar, "blico|público")           ~ FACTOR_PUBLICO,
    str_detect(lugar, "privado|clínica|clinica") ~ FACTOR_PRIVADO,

TRUE                                         ~ FACTOR_PUBLICO
  )
}
costo_imagen <- function(imagen) {
  case_when(

is.na(imagen)                       ~ 0,
    str_detect(imagen, "Ninguno")       ~ 0,
    str_detect(imagen, "Radiograf")     ~ ARANCEL_RX,
    str_detect(imagen, "Ecograf")       ~ ARANCEL_ECOGRAFIA,
    str_detect(imagen, "TAC|Tomograf")  ~ ARANCEL_TAC,
    str_detect(imagen, "Resonan|RMN")   ~ ARANCEL_RMN,
    TRUE                                ~ ARANCEL_RX
  )
}
# Cirugía diferenciada por lesión y parte del cuerpo
# OYT.09.01 artroscopia / OYT.05.04 cadera-espalda / OYT.04.10 osteosíntesis
costo_cirugia <- function(cirugia, lesion, parte) {

case_when(
    is.na(cirugia) | cirugia == "No"   ~ 0,

str_detect(parte,  "Espalda")      ~ ARANCEL_CIRUGIA_DISC,
    str_detect(parte,  "Cadera|pelvis")~ ARANCEL_CIRUGIA_DISC,

str_detect(lesion, "Luxaci")       ~ ARANCEL_CIRUGIA_ART,
    TRUE                               ~ ARANCEL_CIRUGIA_OST

)
}
calcular_ISC <- function(guardia, internacion, cirugia, lesion, parte, imagen, rehab, evacuacion) {

pts_guardia  <- if_else(!is.na(guardia) & str_detect(guardia, "^S[ií]"), 1, 0)
  pts_cirugia  <- if_else(!is.na(cirugia) & str_detect(cirugia, "^S[ií]"), 5, 0)

pts_internac <- case_when(
    is.na(internacion) | internacion == 0 ~ 0,
    internacion <= 3                      ~ 2,
    internacion <= 7                      ~ 4,
    internacion > 7                       ~ 7,
    TRUE                                  ~ 0
  )

  # pts_imagen: suma aditiva por tipo de estudio (corregido: case_when solo captura el primero)

pts_imagen <- if_else(is.na(imagen) | str_detect(imagen, "Ninguno"), 0L,
                        as.integer(str_detect(imagen, "Radiograf")) * 1L +
                          as.integer(str_detect(imagen, "Ecograf"))  * 2L +
                          as.integer(str_detect(imagen, "TAC|Tomograf")) * 2L +
                          as.integer(str_detect(imagen, "Resonan|RMN")) * 3L
  )

  pts_rehab <- case_when(
    is.na(rehab) | rehab == 0 ~ 0,
    rehab < 4                 ~ 1,
    rehab <= 12               ~ 2,
    rehab > 12                ~ 4,
    TRUE                      ~ 0
  )

  pts_evacuacion <- case_when(
    is.na(evacuacion)                             ~ 0,
    str_detect(evacuacion, "Autoe|compa")         ~ 0,
    str_detect(evacuacion, "terrestre|Rescate t") ~ 2,
    str_detect(evacuacion, "éreo|aereo|aéreo")    ~ 5,

TRUE                                          ~ 0
  )

  pts_guardia + pts_internac + pts_cirugia + pts_imagen + pts_rehab + pts_evacuacion
}
# =============================================================================
# 7. CALCULAR ISC Y COSTO POR ACCIDENTE
# =============================================================================
for (i in 1:N_ACC) {
  g   <- paste0("acc", i, "_guardia")

int <- paste0("acc", i, "_internacion")
  cir <- paste0("acc", i, "_cirugia")
  les <- paste0("acc", i, "_lesion")
  par <- paste0("acc", i, "_parte")

img <- paste0("acc", i, "_imagen")
  reh <- paste0("acc", i, "_rehab")

eva <- paste0("acc", i, "_evacuacion")
  lug <- paste0("acc", i, "_lugar")

  fl <- factor_lugar(datos[[lug]])

  datos[[paste0("acc", i, "_ISC")]] <- calcular_ISC(
    datos[[g]], datos[[int]], datos[[cir]], datos[[les]],
    datos[[par]], datos[[img]], datos[[reh]], datos[[eva]]
  )

  datos[[paste0("acc", i, "_costo_guardia")]] <-

if_else(!is.na(datos[[g]]) & str_detect(datos[[g]], "^S[ií]"),

ARANCEL_GUARDIA * fl, 0)

  datos[[paste0("acc", i, "_costo_cirugia")]] <-
    costo_cirugia(datos[[cir]], datos[[les]], datos[[par]]) * fl

  datos[[paste0("acc", i, "_costo_internac")]] <-
    if_else(is.na(datos[[int]]) | datos[[int]] == 0, 0,
            datos[[int]] * ARANCEL_DIA_INTERNAC * fl)

  datos[[paste0("acc", i, "_costo_imagen")]] <- costo_imagen(datos[[img]]) * fl
  datos[[paste0("acc", i, "_costo_rehab")]]  <- datos[[reh]] * ARANCEL_SESION_REHAB * fl

  datos[[paste0("acc", i, "_costo_total")]] <-
    datos[[paste0("acc", i, "_costo_guardia")]]  +
    datos[[paste0("acc", i, "_costo_internac")]] +
    datos[[paste0("acc", i, "_costo_cirugia")]]  +
    datos[[paste0("acc", i, "_costo_imagen")]]   +
    datos[[paste0("acc", i, "_costo_rehab")]]
}
# Totales por persona
isc_cols   <- paste0("acc", 1:N_ACC, "_ISC")
costo_cols <- paste0("acc", 1:N_ACC, "_costo_total")
datos <- datos %>%
  mutate(
    ISC_max         = pmax(!!!syms(isc_cols),   na.rm = TRUE),
    costo_total_24m = rowSums(across(all_of(costo_cols)), na.rm = TRUE)

)
# =============================================================================
# 8. WTP — normalizar formato y calcular punto medio
# =============================================================================
datos <- datos %>%
  mutate(wtp_monto = case_when(
    wtp_monto == "20-Nov" | wtp_monto == "11-20" ~ "11 a 20",
    wtp_monto == "21-30"                         ~ "21 a 30",
    wtp_monto == "31-50"                         ~ "31 a 50",
    wtp_monto == "6-10"                          ~ "6 a 10",
    wtp_monto == "0-5"                           ~ "0 a 5",

wtp_monto == "51+"                           ~ "51 o más",
    TRUE                                         ~ wtp_monto

)) %>%
  mutate(wtp_medio = case_when(
    wtp_monto == "0 a 5"    ~  2.5,
    wtp_monto == "6 a 10"   ~  8.0,
    wtp_monto == "11 a 20"  ~ 15.5,
    wtp_monto == "21 a 30"  ~ 25.5,

wtp_monto == "31 a 50"  ~ 40.5,
    wtp_monto == "51 o más" ~ 60.0,
    TRUE                    ~ NA_real_
  ))
# =============================================================================
# 9. FORMATO LARGO: un accidente por fila (para GLM)
# =============================================================================
acc_largo <- datos %>%
  dplyr::select(timestamp, edad, genero, region, disciplina_principal, nivel,
                tendencia_exposicion, anios_practica, exposicion_horas, n_acc_24m,

matches("^acc[1-7]_")) %>%
  pivot_longer(
    cols          = matches("^acc[1-7]_"),
    names_to      = c("acc_num", ".value"),
    names_pattern = "acc([1-7])_(.*)"
  ) %>%
  filter(!is.na(disc)) %>%
  mutate(acc_num = as.integer(acc_num))
# =============================================================================
# 10. EXPORTAR
# =============================================================================
write_csv(datos,     "datos_wide.csv")
write_csv(acc_largo, "datos_largo.csv")
cat("\nProcesamiento completo\n")
cat("  Respondentes:          ", nrow(datos), "\n")
cat("  Accidentes registrados:", nrow(acc_largo), "\n")
# =============================================================================
# 11. RESUMEN
# =============================================================================
cat("\n--- Exposicion 24m (horas) ---\n")
print(summary(datos$exposicion_horas))
cat("\n--- n_acc_24m ---\n")
print(table(datos$n_acc_24m, useNA = "ifany"))
cat("\n--- ISC maximo por persona ---\n")
print(summary(datos$ISC_max))
cat("\n--- Costo total 24m (ARS) ---\n")
print(summary(datos$costo_total_24m))
cat("\n--- WTP (USD/mes) ---\n")
print(table(datos$wtp_monto, useNA = "ifany"))
cat("\n--- Verificacion outliers n_acc ---\n")
datos %>%
  filter(n_acc_24m >= 6) %>%
  dplyr::select(edad, nivel, disciplina_principal, anios_practica,
                exposicion_horas, n_acc_24m, compite) %>%
  print()
# =============================================================================
# 12. ANÁLISIS DE SENSIBILIDAD — Factor privado
# =============================================================================
# El nomenclador GCBA se usa como base única (FACTOR_PRIVADO = 1.0).
# Este bloque evalúa el impacto de distintos factores sobre los casos privados.
# Fuente limitación: no existe nomenclador público para el sector privado en AR.
cat("\n=== ANÁLISIS DE SENSIBILIDAD — Factor privado ===\n")
factores <- c(1.0, 1.5, 2.0, 2.5)
# Identificar casos con atención privada en accidente 1
privado_mask <- !is.na(datos$acc1_lugar) &
  str_detect(datos$acc1_lugar, "privado|clínica|clinica")
resultados_sens <- sapply(factores, function(f) {

costo_ajustado <- datos$costo_total_24m
  # Aplicar factor solo a los casos privados
  costo_ajustado[privado_mask] <- costo_ajustado[privado_mask] * f
  c(
    media   = round(mean(costo_ajustado, na.rm=TRUE)),
    mediana = round(median(costo_ajustado, na.rm=TRUE)),
    p95     = round(quantile(costo_ajustado, 0.95, na.rm=TRUE))
  )
})
colnames(resultados_sens) <- paste0("Factor_", factores)
cat("\nCosto total 24m (ARS) según factor privado aplicado:\n")
print(resultados_sens)
cat("\nNota: Factor 1.0 = nomenclador GCBA para todos (base)\n")
cat("      Factor 2.5 = estimación conservadora sector privado libre\n")
# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Paso 1: Análisis exploratorio
# Prerequisito: correr primero procesamiento_encuesta_MTB.R
# =============================================================================
library(tidyverse)
library(moments)    # skewness, kurtosis
library(MASS)       # fitdistr
# =============================================================================
# A. ESTADÍSTICAS DESCRIPTIVAS DE LA MUESTRA
# =============================================================================
cat("=== A. PERFIL DE LA MUESTRA ===\n")
cat("Respondentes:", nrow(datos), "\n")
cat("Con lesiones:", sum(datos$tuvo_lesiones == "Si", na.rm=TRUE), "\n")
cat("Tasa de siniestralidad bruta:", round(mean(datos$tuvo_lesiones == "Si", na.rm=TRUE)*100, 1), "%\n\n")
cat("--- Disciplina principal ---\n")
print(table(datos$disciplina_principal))
cat("\n--- Nivel técnico ---\n")
print(table(datos$nivel))
cat("\n--- Región ---\n")
print(table(datos$region))
cat("\n--- Género ---\n")
print(table(datos$genero))
cat("\n--- Edad ---\n")
print(summary(datos$edad))
cat("\n--- Años de práctica ---\n")
print(summary(datos$anios_practica))
cat("\n--- Exposición 24m (horas) ---\n")
print(summary(datos$exposicion_horas))
# =============================================================================
# B. ANÁLISIS DE FRECUENCIA
# =============================================================================
cat("\n=== B. ANÁLISIS DE FRECUENCIA ===\n")
cat("\n--- Distribución de n_acc_24m ---\n")
print(table(datos$n_acc_24m, useNA = "ifany"))
cat("\n--- Estadísticas de n_acc_24m ---\n")
cat("Media:    ", round(mean(datos$n_acc_24m, na.rm=TRUE), 4), "\n")
cat("Varianza: ", round(var(datos$n_acc_24m, na.rm=TRUE), 4), "\n")
cat("Desvío:   ", round(sd(datos$n_acc_24m, na.rm=TRUE), 4), "\n")
cat("Max:      ", max(datos$n_acc_24m, na.rm=TRUE), "\n")
# Test de sobredispersión: varianza/media
media_n  <- mean(datos$n_acc_24m, na.rm=TRUE)
var_n    <- var(datos$n_acc_24m, na.rm=TRUE)
indice_d <- var_n / media_n
cat("\n--- Test de sobredispersión ---\n")
cat("Índice de dispersión (Var/Media):", round(indice_d, 4), "\n")
if (indice_d > 1.2) {
  cat("→ Sobredispersión presente: usar Binomial Negativa\n")
} else if (indice_d < 0.8) {
  cat("→ Subdispersión presente: evaluar Binomial\n")
} else {
  cat("→ Equidispersión aproximada: Poisson es adecuado\n")
}
# Tasa de accidentes por hora de exposición (normalizada a 1000 horas)
datos_con <- datos %>% filter(tuvo_lesiones == "Si")
tasa_por_1000h <- (mean(datos$n_acc_24m, na.rm=TRUE) / mean(datos$exposicion_horas, na.rm=TRUE)) * 1000
cat("\nTasa de accidentes cada 1000 horas de exposición:", round(tasa_por_1000h, 4), "\n")
# Tasa anualizada (dividir por 2 porque la ventana es 24 meses)
cat("Tasa anualizada (accidentes/persona/año):", round(media_n/2, 4), "\n")
# =============================================================================
# C. ANÁLISIS DE SEVERIDAD (ISC y Costo)
# =============================================================================
cat("\n=== C. ANÁLISIS DE SEVERIDAD ===\n")
# Filtrar solo accidentes reales
acc_sev <- acc_largo %>% filter(!is.na(ISC) & ISC > 0)
cat("Accidentes con ISC > 0:", nrow(acc_sev), "\n")
cat("\n--- ISC (Índice de Severidad Clínica) ---\n")
print(summary(acc_sev$ISC))
cat("Skewness: ", round(skewness(acc_sev$ISC), 4), "\n")
cat("Kurtosis: ", round(kurtosis(acc_sev$ISC), 4), "\n")
# Costo solo para accidentes con costo > 0
acc_costo <- acc_largo %>% filter(!is.na(costo_total) & costo_total > 0)
cat("\nAccidentes con costo > 0:", nrow(acc_costo), "\n")
cat("\n--- Costo por accidente (ARS) ---\n")
print(summary(acc_costo$costo_total))
cat("Skewness: ", round(skewness(acc_costo$costo_total), 4), "\n")
cat("Kurtosis: ", round(kurtosis(acc_costo$costo_total), 4), "\n")
# Percentiles clave
cat("\n--- Percentiles del costo ---\n")
perc <- quantile(acc_costo$costo_total, probs = c(0.25, 0.5, 0.75, 0.90, 0.95, 0.99))
print(round(perc))
# Proporción de costo > distintos umbrales
cat("\n--- Concentración de la cola ---\n")
cat("% accidentes con costo > $500k:  ", round(mean(acc_costo$costo_total > 500000)*100, 1), "%\n")
cat("% accidentes con costo > $1M:    ", round(mean(acc_costo$costo_total > 1000000)*100, 1), "%\n")
cat("% accidentes con costo > $3M:    ", round(mean(acc_costo$costo_total > 3000000)*100, 1), "%\n")
cat("% costo acumulado top 10%:       ", round(sum(sort(acc_costo$costo_total, decreasing=TRUE)[1:ceiling(nrow(acc_costo)*0.1)]) / sum(acc_costo$costo_total)*100, 1), "%\n")
# =============================================================================
# D. ANÁLISIS POR SUBGRUPOS (para hipótesis del modelo)
# =============================================================================
cat("\n=== D. FRECUENCIA POR SUBGRUPOS ===\n")
cat("\n--- Tasa de accidentes por nivel técnico ---\n")
datos %>%
  group_by(nivel) %>%
  summarise(
    n          = n(),
    acc_total  = sum(n_acc_24m, na.rm=TRUE),
    media_acc  = round(mean(n_acc_24m, na.rm=TRUE), 3),
    expo_media = round(mean(exposicion_horas, na.rm=TRUE), 1),
    tasa_1000h = round(acc_total / sum(exposicion_horas, na.rm=TRUE) * 1000, 3)

) %>%
  print()
cat("\n--- Tasa de accidentes por disciplina principal ---\n")
datos %>%
  filter(str_detect(disciplina_principal, "Downhill|DH|Enduro")) %>%

group_by(disciplina_principal) %>%
  summarise(
    n          = n(),
    acc_total  = sum(n_acc_24m, na.rm=TRUE),
    media_acc  = round(mean(n_acc_24m, na.rm=TRUE), 3),
    tasa_1000h = round(acc_total / sum(exposicion_horas, na.rm=TRUE) * 1000, 3)

) %>%
  print()
cat("\n--- Tasa de accidentes por región ---\n")
datos %>%
  group_by(region) %>%
  summarise(
    n          = n(),
    acc_total  = sum(n_acc_24m, na.rm=TRUE),
    media_acc  = round(mean(n_acc_24m, na.rm=TRUE), 3),
    tasa_1000h = round(acc_total / sum(exposicion_horas, na.rm=TRUE) * 1000, 3)
  ) %>%
  arrange(desc(tasa_1000h)) %>%

print()
cat("\n--- Tasa de accidentes: compite vs no compite ---\n")
datos %>%
  group_by(compite) %>%
  summarise(
    n          = n(),
    media_acc  = round(mean(n_acc_24m, na.rm=TRUE), 3),
    tasa_1000h = round(sum(n_acc_24m, na.rm=TRUE) / sum(exposicion_horas, na.rm=TRUE) * 1000, 3)

) %>%
  print()
# =============================================================================
# E. CORRELACIONES ENTRE VARIABLES
# =============================================================================
cat("\n=== E. CORRELACIONES CON n_acc_24m ===\n")
vars_num <- datos %>%
  dplyr::select(n_acc_24m, edad, anios_practica, exposicion_horas,
                meses_anio, dias_semana, horas_dia) %>%

drop_na()
cor_mat <- cor(vars_num, method = "spearman")
cat("\n--- Correlación de Spearman con n_acc_24m ---\n")
print(round(cor_mat["n_acc_24m", ], 3))
# =============================================================================
# F. GRÁFICOS (guardar como PNG)
# =============================================================================
cat("\n=== F. GENERANDO GRÁFICOS ===\n")
# 1. Histograma de n_acc_24m
p1 <- ggplot(datos, aes(x = n_acc_24m)) +

geom_bar(fill = "#378ADD", color = "white", width = 0.6) +

labs(title = "Distribución de accidentes por persona (24 meses)",
       x = "N° de accidentes", y = "Frecuencia") +

theme_minimal(base_size = 13)
ggsave("graf_01_freq_nacc.png", p1, width = 7, height = 4, dpi = 150)
# 2. Histograma de costo con log-escala
p2 <- ggplot(acc_costo, aes(x = costo_total)) +

geom_histogram(fill = "#e24b4a", color = "white", bins = 25) +
  scale_x_log10(labels = scales::comma) +

labs(title = "Distribución del costo por accidente (escala log)",
       x = "Costo ARS (log)", y = "Frecuencia") +

theme_minimal(base_size = 13)
ggsave("graf_02_sev_costo_log.png", p2, width = 7, height = 4, dpi = 150)
# 3. Costo por nivel técnico
p3 <- datos %>%
  filter(costo_total_24m > 0) %>%
  ggplot(aes(x = reorder(nivel, costo_total_24m, median), y = costo_total_24m)) +

geom_boxplot(fill = "#534AB7", color = "white", outlier.color = "#e24b4a") +
  scale_y_log10(labels = scales::comma) +
  coord_flip() +

labs(title = "Costo total 24m por nivel técnico",
       x = "", y = "Costo ARS (log)") +

theme_minimal(base_size = 11)
ggsave("graf_03_costo_por_nivel.png", p3, width = 8, height = 4, dpi = 150)
# 4. Exposición vs n_acc
p4 <- ggplot(datos, aes(x = exposicion_horas, y = n_acc_24m)) +

geom_point(alpha = 0.4, color = "#1D9E75", size = 2) +
  geom_smooth(method = "glm", method.args = list(family = "poisson"),

se = TRUE, color = "#e24b4a") +
  labs(title = "Exposición vs N° de accidentes",
       x = "Horas de exposición (24m)", y = "N° de accidentes") +

theme_minimal(base_size = 13)
ggsave("graf_04_expo_vs_nacc.png", p4, width = 7, height = 4, dpi = 150)
# 5. ISC distribución
p5 <- ggplot(acc_sev, aes(x = ISC)) +
  geom_histogram(fill = "#EF9F27", color = "white", bins = 15) +

labs(title = "Distribución del ISC (accidentes graves)",
       x = "Índice de Severidad Clínica", y = "Frecuencia") +

theme_minimal(base_size = 13)
ggsave("graf_05_ISC.png", p5, width = 7, height = 4, dpi = 150)
# 6. Q-Q plot del log(costo) — verificar normalidad en log-escala (Lognormal)
log_costo <- log(acc_costo$costo_total)
png("graf_06_qq_logcosto.png", width=700, height=500, res=150)
qqnorm(log_costo, main="Q-Q plot de log(Costo) — verificación Lognormal",
       col="#378ADD", pch=16, cex=0.7)
qqline(log_costo, col="#e24b4a", lwd=2)
dev.off()
cat("Gráficos guardados en el directorio de trabajo.\n")
# =============================================================================
# G. RESUMEN PARA LA TESINA
# =============================================================================
cat("\n=== G. RESUMEN EJECUTIVO PARA LA TESINA ===\n")
cat("
FRECUENCIA:
  - Media n_acc_24m:      ", round(media_n, 4), "
  - Varianza n_acc_24m:   ", round(var_n, 4), "
  - Índice dispersión:    ", round(indice_d, 4), "
  - Tasa c/1000h expo:    ", round(tasa_por_1000h, 4), "
SEVERIDAD (accidentes con costo > 0):
  - N accidentes:         ", nrow(acc_costo), "
  - Media costo:          ARS", format(round(mean(acc_costo$costo_total)), big.mark="."), "
  - Mediana costo:        ARS", format(round(median(acc_costo$costo_total)), big.mark="."), "

- P95 costo:            ARS", format(round(quantile(acc_costo$costo_total, 0.95)), big.mark="."), "
  - Skewness costo:       ", round(skewness(acc_costo$costo_total), 4), "
CONCLUSIÓN EXPLORATORIA:
  - Frecuencia: ", ifelse(indice_d > 1.2, "BINOMIAL NEGATIVA (sobredispersión)", "POISSON (equidispersión)"), "

- Severidad:  LOGNORMAL seleccionada (AIC=5444.66 vs Gamma=5452.52;
Δ
AIC=7.86; AD A²=2.55 vs 3.59)
#                 Gamma como modelo alternativo en análisis de sensibilidad
")
# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Paso 2: Modelo de frecuencia (Poisson y Binomial Negativa)
# Prerequisito: correr primero procesamiento_encuesta_MTB.R
# =============================================================================
library(tidyverse)
library(MASS)         # glm.nb para Binomial Negativa
# AER no requerido — test de sobredispersión implementado manualmente
library(lmtest)       # lrtest
# =============================================================================
# A. PREPARACIÓN DE DATOS
# =============================================================================
# Variable dependiente: n_acc_24m
# Offset: log(exposicion_horas) — normaliza por exposición individual
# Covariables candidatas según hipótesis del Anexo I:
#   - nivel (factor de riesgo por experiencia)
#   - disciplina_principal (DH vs Enduro)
#   - region
#   - tendencia_exposicion
#   - anios_practica
#   - compite
# Limpiar y preparar
datos_modelo <- datos %>%
  filter(!is.na(n_acc_24m) & !is.na(exposicion_horas) & exposicion_horas > 0) %>%
  mutate(
    nivel_f      = factor(nivel, levels = c(
      "Principiante ((control básico, terrenos sencillos)",
      "Intermedio (buen control en la mayoría de los terrenos)",
      "Avanzado (manejo técnico en terrenos exigentes)",
      "Experto / Competitivo (participa o entrena regularmente para competir)"
    ), labels = c("Principiante", "Intermedio", "Avanzado", "Experto")),

disc_f       = factor(if_else(str_detect(disciplina_principal, "Downhill|DH"),
                                  "DH", "Enduro")),
    region_f     = factor(case_when(
      str_detect(region, "Patagonia")         ~ "Patagonia",
      str_detect(region, "NOA")               ~ "NOA",
      str_detect(region, "Centro")            ~ "Centro",
      str_detect(region, "Buenos Aires|CABA") ~ "BsAs",
      TRUE                                    ~ "Otro"
    )),
    tendencia_f  = factor(case_when(

str_detect(tendencia_exposicion, "imilar")  ~ "Similar",

str_detect(tendencia_exposicion, "más|mas") ~ "Antes_mas",
      str_detect(tendencia_exposicion, "menos")   ~ "Antes_menos",

TRUE                                        ~ "Variable"
    )),
    compite_f    = factor(compite),

log_expo     = log(exposicion_horas)
  )
cat("Observaciones para el modelo:", nrow(datos_modelo), "\n")
cat("Distribución n_acc_24m:\n")
print(table(datos_modelo$n_acc_24m))
# =============================================================================
# B. MODELO 1 — POISSON
# =============================================================================
cat("\n=== B. MODELO POISSON ===\n")
mod_poisson <- glm(

n_acc_24m ~ nivel_f + disc_f + region_f + tendencia_f +

anios_practica + compite_f + offset(log_expo),
  family  = poisson(link = "log"),
  data    = datos_modelo
)
cat("\n--- Resumen Poisson ---\n")
print(summary(mod_poisson))
cat("\nAIC Poisson:", round(AIC(mod_poisson), 2), "\n")
cat("BIC Poisson:", round(BIC(mod_poisson), 2), "\n")
# Test de sobredispersión formal
cat("\n--- Test de sobredispersión (Cameron & Trivedi) ---\n")
# Test manual de sobredispersión: comparar desvio residual vs grados de libertad
disp_ratio <- sum(residuals(mod_poisson, type="pearson")^2) / df.residual(mod_poisson)
disp_test_pval <- pchisq(sum(residuals(mod_poisson, type="pearson")^2), df.residual(mod_poisson), lower.tail=FALSE)
cat("Ratio dispersión (Pearson):", round(disp_ratio, 4), "\n")
cat("p-valor sobredispersión:   ", round(disp_test_pval, 4), "\n")
if (disp_test_pval < 0.05) {

cat("→ Sobredispersión significativa (p <", round(disp_test_pval, 4), ")\n")
  cat("→ Se rechaza Poisson, se usa Binomial Negativa\n")
} else {
  cat("→ No hay evidencia de sobredispersión, Poisson es adecuado\n")
}
# =============================================================================
# C. MODELO 2 — BINOMIAL NEGATIVA
# =============================================================================
cat("\n=== C. MODELO BINOMIAL NEGATIVA ===\n")
mod_bn <- glm.nb(
  n_acc_24m ~ nivel_f + disc_f + region_f + tendencia_f +
    anios_practica + compite_f + offset(log_expo),
  data = datos_modelo
)
cat("\n--- Resumen Binomial Negativa ---\n")
print(summary(mod_bn))
cat("\nAIC BN:", round(AIC(mod_bn), 2), "\n")
cat("BIC BN:", round(BIC(mod_bn), 2), "\n")
cat("Theta (parámetro dispersión):", round(mod_bn$theta, 4), "\n")
# =============================================================================
# D. COMPARACIÓN DE MODELOS
# =============================================================================
cat("\n=== D. COMPARACIÓN POISSON vs BINOMIAL NEGATIVA ===\n")
cat("\n--- Tabla comparativa ---\n")
comp <- data.frame(
  Modelo = c("Poisson", "Binomial Negativa"),
  AIC    = round(c(AIC(mod_poisson), AIC(mod_bn)), 2),
  BIC    = round(c(BIC(mod_poisson), BIC(mod_bn)), 2),
  LogLik = round(c(logLik(mod_poisson), logLik(mod_bn)), 2)
)
print(comp)
# Test de razón de verosimilitud Poisson vs BN
cat("\n--- Likelihood Ratio Test (Poisson vs BN) ---\n")
lrt <- lrtest(mod_poisson, mod_bn)
print(lrt)
mejor <- if_else(AIC(mod_bn) < AIC(mod_poisson), "BINOMIAL NEGATIVA", "POISSON")
cat("\n→ Modelo seleccionado por AIC:", mejor, "\n")
# =============================================================================
# E. MODELO SELECCIONADO — ANÁLISIS DE COEFICIENTES
# =============================================================================
cat("\n=== E. INTERPRETACIÓN DEL MODELO SELECCIONADO ===\n")
# Usar BN como modelo principal
mod_final <- mod_bn
cat("\n--- Incidence Rate Ratios (IRR = exp(coef)) ---\n")
irr <- exp(coef(mod_final))
ci  <- exp(confint(mod_final))
irr_tabla <- data.frame(
  IRR    = round(irr, 4),
  CI_2.5 = round(ci[,1], 4),
  CI_97.5= round(ci[,2], 4),
  p_valor= round(summary(mod_final)$coefficients[,4], 4)
)
print(irr_tabla)
cat("\n--- Interpretación práctica ---\n")
cat("IRR > 1: la variable aumenta la tasa de accidentes\n")
cat("IRR < 1: la variable reduce la tasa de accidentes\n")
cat("IRR = 1: sin efecto\n")
# =============================================================================
# F. MODELO REDUCIDO — SOLO VARIABLES SIGNIFICATIVAS
# =============================================================================
cat("\n=== F. MODELO REDUCIDO (solo variables significativas p < 0.10) ===\n")
# Identificar variables significativas
pvals <- summary(mod_bn)$coefficients[,4]
sig_vars <- names(pvals[pvals < 0.10])
cat("Variables significativas al 10%:", paste(sig_vars, collapse=", "), "\n")
# Modelo reducido
mod_reducido <- glm.nb(
  n_acc_24m ~ nivel_f + disc_f + offset(log_expo),
  data = datos_modelo
)
cat("\n--- Comparación modelo completo vs reducido ---\n")
comp2 <- data.frame(
  Modelo = c("BN Completo", "BN Reducido"),

AIC    = round(c(AIC(mod_bn), AIC(mod_reducido)), 2),
  BIC    = round(c(BIC(mod_bn), BIC(mod_reducido)), 2)
)
print(comp2)
lrt2 <- lrtest(mod_reducido, mod_bn)
cat("\nLRT modelo reducido vs completo:\n")
print(lrt2)
# =============================================================================
# G. TASA DE ACCIDENTES PREDICHA
# =============================================================================
cat("\n=== G. TASAS PREDICHAS POR PERFIL ===\n")
# Crear perfiles representativos
perfiles <- expand.grid(
  nivel_f     = c("Principiante", "Intermedio", "Avanzado", "Experto"),
  disc_f      = c("DH", "Enduro"),
  region_f    = "Patagonia",
  tendencia_f = "Similar",
  anios_practica = median(datos_modelo$anios_practica, na.rm=TRUE),
  compite_f   = "Si",
  log_expo    = log(mean(datos_modelo$exposicion_horas, na.rm=TRUE))
)
perfiles$tasa_predicha_24m <- predict(mod_bn, newdata=perfiles, type="response")
perfiles$tasa_anual        <- round(perfiles$tasa_predicha_24m / 2, 4)
cat("\nTasa de accidentes predicha por perfil (anualizada):\n")
print(perfiles %>%
        dplyr::select(nivel_f, disc_f, tasa_anual) %>%
        arrange(disc_f, nivel_f))
# =============================================================================
# H. GRÁFICOS DIAGNÓSTICOS
# =============================================================================
cat("\n=== H. GENERANDO GRÁFICOS ===\n")
# 1. Valores ajustados vs residuos
png("graf_07_residuos_bn.png", width=700, height=500, res=150)
plot(fitted(mod_bn), residuals(mod_bn, type="pearson"),

xlab="Valores ajustados", ylab="Residuos de Pearson",
     main="Diagnóstico BN: residuos vs ajustados",

col="#378ADD", pch=16, cex=0.7)
abline(h=0, col="#e24b4a", lwd=2)
dev.off()
# 2. IRR con intervalos de confianza
irr_df <- data.frame(
  variable = rownames(irr_tabla)[-1],

IRR      = irr_tabla$IRR[-1],
  CI_low   = irr_tabla$CI_2.5[-1],
  CI_high  = irr_tabla$CI_97.5[-1],
  sig      = irr_tabla$p_valor[-1] < 0.05
) %>% filter(!is.na(IRR))
p_irr <- ggplot(irr_df, aes(x=reorder(variable, IRR), y=IRR, color=sig)) +
  geom_point(size=3) +
  geom_errorbar(aes(ymin=CI_low, ymax=CI_high), width=0.2) +
  geom_hline(yintercept=1, linetype="dashed", color="#e24b4a") +
  coord_flip() +
  scale_color_manual(values=c("gray50","#378ADD"),

labels=c("No significativo","Significativo (p<0.05)")) +

labs(title="Incidence Rate Ratios — Modelo Binomial Negativa",
       x="", y="IRR (exp(coef))", color="") +
  theme_minimal(base_size=11)
ggsave("graf_08_IRR_bn.png", p_irr, width=8, height=5, dpi=150)
# 3. Tasas predichas por nivel y disciplina
p_tasas <- perfiles %>%
  ggplot(aes(x=nivel_f, y=tasa_anual, fill=disc_f)) +

geom_col(position="dodge") +
  scale_fill_manual(values=c("#378ADD","#1D9E75")) +

labs(title="Tasa anual de accidentes predicha por nivel y disciplina",
       x="Nivel técnico", y="Accidentes/año", fill="Disciplina") +

theme_minimal(base_size=12)
ggsave("graf_09_tasas_predichas.png", p_tasas, width=8, height=4, dpi=150)
cat("Gráficos guardados.\n")
# =============================================================================
# I. RESUMEN PARA LA TESINA
# =============================================================================
cat("\n=== I. RESUMEN EJECUTIVO PASO 2 ===\n")
cat("
MODELO DE FRECUENCIA:
  - Poisson AIC:          ", round(AIC(mod_poisson), 2), "
  - BN AIC:               ", round(AIC(mod_bn), 2), "

- Modelo seleccionado:  BINOMIAL NEGATIVA (menor AIC; ΔAIC=24,29; θ=1,490 confirma sobredispersión residual capturada)

- Theta (dispersión):   ", round(mod_bn$theta, 4), "
VARIABLES SIGNIFICATIVAS (p < 0.05):
")
sig05 <- names(pvals[pvals < 0.05])
cat(paste(" ", sig05, collapse="\n"), "\n")
cat("
TASA MEDIA PREDICHA (anual):
  - DH Principiante:  ", round(perfiles$tasa_anual[perfiles$nivel_f=="Principiante" & perfiles$disc_f=="DH"], 4), "
  - DH Experto:       ", round(perfiles$tasa_anual[perfiles$nivel_f=="Experto" & perfiles$disc_f=="DH"], 4), "
  - Enduro Principiante:", round(perfiles$tasa_anual[perfiles$nivel_f=="Principiante" & perfiles$disc_f=="Enduro"], 4), "
  - Enduro Experto:   ", round(perfiles$tasa_anual[perfiles$nivel_f=="Experto" & perfiles$disc_f=="Enduro"], 4), "
")
# =============================================================================
# J. MODELO AJUSTADO — Principiante colapsado con Intermedio
# =============================================================================
# Justificación: n=14 Principiantes con solo 2 accidentes genera estimador
# inestable (IRR ~47x). Se colapsa con Intermedio y se documenta como
# limitación metodológica por tamaño muestral insuficiente en esa categoría.
cat("\n=== J. MODELO AJUSTADO (Principiante + Intermedio colapsados) ===\n")
datos_modelo <- datos_modelo %>%
  mutate(nivel_f2 = fct_collapse(nivel_f,
                                 "Princ_Interm" = c("Principiante", "Intermedio"),
                                 "Avanzado"     = "Avanzado",
                                 "Experto"      = "Experto"
  ),
  nivel_f2 = relevel(nivel_f2, ref = "Princ_Interm"))
# Reajustar BN con nivel colapsado (theta=1,490; modelo seleccionado es Binomial Negativa)
mod_bn2 <- glm.nb(
  n_acc_24m ~ nivel_f2 + disc_f + region_f + tendencia_f +
    anios_practica + compite_f + offset(log_expo),
  # (glm.nb no requiere argumento family; usa Binomial Negativa por defecto)
  data   = datos_modelo
)
cat("\n--- Resumen BN ajustado ---\n")
print(summary(mod_bn2))
cat("\nAIC:", round(AIC(mod_bn2), 2), "\n")
cat("BIC:", round(BIC(mod_bn2), 2), "\n")
cat("\n--- IRR modelo ajustado ---\n")
irr2   <- exp(coef(mod_bn2))
ci2    <- exp(confint(mod_bn2))
pvals2 <- summary(mod_bn2)$coefficients[,4]
irr2_tabla <- data.frame(
  IRR     = round(irr2, 4),
  CI_2.5  = round(ci2[,1], 4),
  CI_97.5 = round(ci2[,2], 4),
  p_valor = round(pvals2, 4)
)
print(irr2_tabla)
# Tasas predichas con modelo ajustado
perfiles2 <- expand.grid(
  nivel_f2       = c("Princ_Interm", "Avanzado", "Experto"),
  disc_f         = c("DH", "Enduro"),
  region_f       = "Patagonia",
  tendencia_f    = "Similar",
  anios_practica = median(datos_modelo$anios_practica, na.rm=TRUE),
  compite_f      = "Si",
  log_expo       = log(mean(datos_modelo$exposicion_horas, na.rm=TRUE))
)
perfiles2$tasa_24m  <- predict(mod_bn2, newdata=perfiles2, type="response")
perfiles2$tasa_anual <- round(perfiles2$tasa_24m / 2, 4)
cat("\nTasas anuales predichas (modelo ajustado):\n")
print(perfiles2 %>%
        dplyr::select(nivel_f2, disc_f, tasa_anual) %>%
        arrange(disc_f, nivel_f2))
# Gráfico tasas ajustadas
p_tasas2 <- perfiles2 %>%
  ggplot(aes(x=nivel_f2, y=tasa_anual, fill=disc_f)) +

geom_col(position="dodge") +
  scale_fill_manual(values=c("#378ADD","#1D9E75")) +

labs(title="Tasa anual de accidentes predicha — modelo ajustado",
       x="Nivel técnico", y="Accidentes/año", fill="Disciplina") +

theme_minimal(base_size=12)
ggsave("graf_09b_tasas_ajustadas.png", p_tasas2, width=7, height=4, dpi=150)
cat("\n=== MODELO FINAL SELECCIONADO: BINOMIAL NEGATIVA con nivel_f2 ===\n")
cat("Justificación: theta=1,490 confirma sobredispersión; BN seleccionada. Principiante colapsado con Intermedio (n=14).\n")
cat("Principiante colapsado con Intermedio por n insuficiente (n=14).\n")
# =============================================================================
# K. BONDAD DE AJUSTE — Q-Q, P-P y KS sobre residuos
# =============================================================================
cat("\n=== K. BONDAD DE AJUSTE ===\n")
# Residuos de Pearson del modelo final
res_pearson <- residuals(mod_bn2, type = "pearson")
res_deviance <- residuals(mod_bn2, type = "deviance")
# --- K1. Test de Kolmogorov-Smirnov sobre residuos de Pearson ---
cat("\n--- Test Kolmogorov-Smirnov (residuos vs Normal) ---\n")
ks_test <- ks.test(scale(res_pearson), "pnorm")
print(ks_test)
if (ks_test$p.value > 0.05) {

cat("→ No se rechaza normalidad de residuos (p =", round(ks_test$p.value, 4), ")\n")
} else {
  cat("→ Se rechaza normalidad de residuos (p =", round(ks_test$p.value, 4), ")\n")
  cat("  Nota: en GLM Poisson los residuos no son normales por definición,\n")
  cat("  el KS es orientativo. Ver gráficos Q-Q y desvío residual.\n")
}
# --- K2. Desvío residual vs grados de libertad ---
cat("\n--- Desvío residual ---\n")
dev_ratio <- deviance(mod_bn2) / df.residual(mod_bn2)
cat("Desvío residual:      ", round(deviance(mod_bn2), 4), "\n")
cat("Grados de libertad:   ", df.residual(mod_bn2), "\n")
cat("Ratio desvío/gl:      ", round(dev_ratio, 4), "\n")
if (dev_ratio < 1.5) {
  cat("→ Ajuste aceptable (ratio < 1.5)\n")
} else {

cat("→ Posible sobreajuste o subdispersión residual\n")
}
# --- K3. Frecuencias observadas vs predichas ---
cat("\n--- Frecuencias observadas vs predichas ---\n")
obs  <- table(datos_modelo$n_acc_24m)
pred <- table(round(fitted(mod_bn2)))
freq_comp <- data.frame(
  n_acc    = as.integer(names(obs)),
  observado = as.integer(obs),
  predicho  = sapply(as.integer(names(obs)), function(k) {
    sum(dnbinom(k, mu = fitted(mod_bn2), size = mod_bn2$theta))

}) %>% round(2)
)
print(freq_comp)
# Chi-cuadrado de bondad de ajuste sobre frecuencias
chi_stat <- sum((freq_comp$observado - freq_comp$predicho)^2 / freq_comp$predicho)
chi_pval <- pchisq(chi_stat, df = nrow(freq_comp) - 1, lower.tail = FALSE)
cat("\nChi-cuadrado bondad de ajuste:\n")
cat("  Estadístico:", round(chi_stat, 4), "\n")
cat("  p-valor:    ", round(chi_pval, 4), "\n")
if (chi_pval > 0.05) {
  cat("→ No se rechaza el ajuste del modelo (p > 0.05)\n")
} else {
  cat("→ Se rechaza el ajuste del modelo (p < 0.05)\n")
}
# --- K4. Gráficos ---
# Q-Q plot de residuos de desvío
png("graf_10_qq_residuos_frecuencia.png", width=700, height=500, res=150)
qqnorm(res_deviance,
       main="Q-Q plot residuos de desvío — Modelo Binomial Negativa",

col="#378ADD", pch=16, cex=0.7)
qqline(res_deviance, col="#e24b4a", lwd=2)
dev.off()
# P-P plot
png("graf_11_pp_residuos_frecuencia.png", width=700, height=500, res=150)
n <- length(res_pearson)
p_teorico  <- pnorm(sort(scale(res_pearson)))
p_empirico <- (1:n) / n
plot(p_teorico, p_empirico,
     main="P-P plot residuos — Modelo Binomial Negativa",
     xlab="Probabilidad teórica (Normal)", ylab="Probabilidad empírica",

col="#378ADD", pch=16, cex=0.7)
abline(0, 1, col="#e24b4a", lwd=2)
dev.off()
# Frecuencias observadas vs predichas
freq_long <- freq_comp %>%
  pivot_longer(cols=c(observado, predicho), names_to="tipo", values_to="n")
p_freq <- ggplot(freq_long, aes(x=factor(n_acc), y=n, fill=tipo)) +
  geom_col(position="dodge") +
  scale_fill_manual(values=c("#378ADD","#e24b4a"),

labels=c("Observado","Predicho")) +
  labs(title="Frecuencias observadas vs predichas — Modelo Binomial Negativa",
       x="N° de accidentes", y="Frecuencia", fill="") +

theme_minimal(base_size=12)
ggsave("graf_12_obs_vs_pred_frecuencia.png", p_freq, width=7, height=4, dpi=150)
cat("\nGráficos K guardados: graf_10, graf_11, graf_12\n")
cat("\n=== PASO 2 COMPLETO ===\n")
cat("Modelo final: BINOMIAL NEGATIVA con nivel_f2 + offset(log_expo)\n")
cat("Bondad de ajuste: ver gráficos Q-Q, P-P y frecuencias obs vs pred\n")
# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Paso 3: Modelo de severidad (Lognormal y Gamma)
# Prerequisito: correr primero procesamiento_encuesta_MTB.R
# =============================================================================
library(tidyverse)
library(fitdistrplus)  # fitdist, gofstat
library(actuar)        # distribuciones actuariales (no utilizada directamente en este script)
library(ggplot2)
# =============================================================================
# A. PREPARACIÓN DE DATOS DE SEVERIDAD
# =============================================================================
cat("=== A. DATOS DE SEVERIDAD ===\n")
# Usar solo accidentes con costo > 0
sev <- acc_largo %>%
  filter(!is.na(costo_total) & costo_total > 0) %>%
  dplyr::select(costo_total, ISC, lesion, parte, disc, nivel, lugar)
cat("N accidentes con costo > 0:", nrow(sev), "\n")
cat("\nEstadísticas descriptivas del costo:\n")
print(summary(sev$costo_total))
cat("\nMomentos:\n")
cat("  Media:     ARS", format(round(mean(sev$costo_total)), big.mark=","), "\n")
cat("  Desvío:    ARS", format(round(sd(sev$costo_total)), big.mark=","), "\n")
cat("  CV:       ", round(sd(sev$costo_total)/mean(sev$costo_total), 4), "\n")
cat("  Skewness: ", round(moments::skewness(sev$costo_total), 4), "\n")
cat("  Kurtosis: ", round(moments::kurtosis(sev$costo_total), 4), "\n")
# =============================================================================
# B. AJUSTE LOGNORMAL
# =============================================================================
cat("\n=== B. AJUSTE LOGNORMAL ===\n")
fit_ln <- fitdist(sev$costo_total, "lnorm", method = "mle")
cat("\nParámetros Lognormal (MLE):\n")
print(summary(fit_ln))
cat("\nAIC Lognormal:", round(fit_ln$aic, 4), "\n")
cat("BIC Lognormal:", round(fit_ln$bic, 4), "\n")
# Parámetros
mu_ln    <- fit_ln$estimate["meanlog"]
sigma_ln <- fit_ln$estimate["sdlog"]
cat("\nMedia teórica:  ARS", format(round(exp(mu_ln + sigma_ln^2/2)), big.mark=","), "\n")
cat("Mediana teórica: ARS", format(round(exp(mu_ln)), big.mark=","), "\n")
# =============================================================================
# C. AJUSTE GAMMA
# =============================================================================
cat("\n=== C. AJUSTE GAMMA ===\n")
fit_gm <- fitdist(sev$costo_total, "gamma", method = "mle")
cat("\nParámetros Gamma (MLE):\n")
print(summary(fit_gm))
cat("\nAIC Gamma:", round(fit_gm$aic, 4), "\n")
cat("BIC Gamma:", round(fit_gm$bic, 4), "\n")
shape_gm <- fit_gm$estimate["shape"]
rate_gm  <- fit_gm$estimate["rate"]
cat("\nMedia teórica:  ARS", format(round(shape_gm/rate_gm), big.mark=","), "\n")
cat("Varianza teórica: ARS²", format(round(shape_gm/rate_gm^2), big.mark=","), "\n")
# =============================================================================
# D. COMPARACIÓN DE MODELOS
# =============================================================================
cat("\n=== D. COMPARACIÓN LOGNORMAL vs GAMMA ===\n")
comp_sev <- data.frame(
  Modelo = c("Lognormal", "Gamma"),
  AIC    = round(c(fit_ln$aic, fit_gm$aic), 2),
  BIC    = round(c(fit_ln$bic, fit_gm$bic), 2),
  LogLik = round(c(fit_ln$loglik, fit_gm$loglik), 2)
)
print(comp_sev)
mejor_sev <- ifelse(fit_ln$aic < fit_gm$aic, "LOGNORMAL", "GAMMA")
cat("\n-> Modelo seleccionado por AIC:", mejor_sev, "\n")
# =============================================================================
# E. PRUEBAS DE BONDAD DE AJUSTE
# =============================================================================
cat("\n=== E. BONDAD DE AJUSTE ===\n")
# Kolmogorov-Smirnov
ks_ln <- ks.test(sev$costo_total, "plnorm", mu_ln, sigma_ln)
ks_gm <- ks.test(sev$costo_total, "pgamma", shape_gm, rate_gm)
cat("\n--- Kolmogorov-Smirnov ---\n")
cat("Lognormal: D =", round(ks_ln$statistic, 4), "  p =", round(ks_ln$p.value, 4), "\n")
cat("Gamma:     D =", round(ks_gm$statistic, 4), "  p =", round(ks_gm$p.value, 4), "\n")
# Anderson-Darling (via gofstat de fitdistrplus)
gof <- gofstat(list(fit_ln, fit_gm),
               fitnames = c("Lognormal", "Gamma"))
cat("\n--- Anderson-Darling ---\n")
print(gof$ad)
cat("\n--- KS estadístico ---\n")
print(gof$ks)
cat("\n--- Conclusión bondad de ajuste ---\n")
cat("Lognormal KS p-valor:", round(ks_ln$p.value, 4), "\n")
cat("Gamma     KS p-valor:", round(ks_gm$p.value, 4), "\n")
if (ks_ln$p.value > ks_gm$p.value) {

cat("-> Lognormal tiene mejor ajuste KS\n")
} else {
  cat("-> Gamma tiene mejor ajuste KS\n")
}
# =============================================================================
# F. PERCENTILES Y VALOR EN RIESGO
# =============================================================================
cat("\n=== F. PERCENTILES DEL MODELO SELECCIONADO ===\n")
probs <- c(0.50, 0.75, 0.90, 0.95, 0.99)
perc_ln <- qlnorm(probs, mu_ln, sigma_ln)
perc_gm <- qgamma(probs, shape_gm, rate_gm)
perc_obs <- quantile(sev$costo_total, probs)
perc_tabla <- data.frame(
  Percentil  = paste0("P", probs*100),
  Observado  = format(round(perc_obs), big.mark=","),
  Lognormal  = format(round(perc_ln), big.mark=","),
  Gamma      = format(round(perc_gm), big.mark=",")
)
print(perc_tabla)
cat("\nVaR 95% Lognormal: ARS", format(round(qlnorm(0.95, mu_ln, sigma_ln)), big.mark=","), "\n")
cat("VaR 99% Lognormal: ARS", format(round(qlnorm(0.99, mu_ln, sigma_ln)), big.mark=","), "\n")
cat("VaR 95% Gamma:     ARS", format(round(qgamma(0.95, shape_gm, rate_gm)), big.mark=","), "\n")
cat("VaR 99% Gamma:     ARS", format(round(qgamma(0.99, shape_gm, rate_gm)), big.mark=","), "\n")
# =============================================================================
# G. GRÁFICOS
# =============================================================================
cat("\n=== G. GENERANDO GRÁFICOS ===\n")
# 1. Histograma con densidades ajustadas
x_seq <- seq(min(sev$costo_total), max(sev$costo_total), length.out=500)
dens_ln <- dlnorm(x_seq, mu_ln, sigma_ln)
dens_gm <- dgamma(x_seq, shape_gm, rate_gm)
p_dens <- ggplot(sev, aes(x=costo_total)) +
  geom_histogram(aes(y=after_stat(density)), bins=20,
                 fill="#378ADD", alpha=0.5, color="white") +
  geom_line(data=data.frame(x=x_seq, y=dens_ln),
            aes(x=x, y=y), color="#e24b4a", linewidth=1.2, linetype="solid") +
  geom_line(data=data.frame(x=x_seq, y=dens_gm),
            aes(x=x, y=y), color="#1D9E75", linewidth=1.2, linetype="dashed") +
  scale_x_continuous(labels=scales::comma) +

labs(title="Ajuste de distribuciones al costo por accidente",
       subtitle="Rojo: Lognormal | Verde: Gamma",
       x="Costo ARS", y="Densidad") +

theme_minimal(base_size=12)
ggsave("graf_13_ajuste_severidad.png", p_dens, width=8, height=4, dpi=150)
# 2. Q-Q plot Lognormal
png("graf_14_qq_lognormal.png", width=700, height=500, res=150)
qlnorm_teorico <- qlnorm(ppoints(nrow(sev)), mu_ln, sigma_ln)
plot(sort(qlnorm_teorico), sort(sev$costo_total),
     main="Q-Q plot — Lognormal",

xlab="Cuantiles teóricos", ylab="Cuantiles observados",

col="#378ADD", pch=16, cex=0.7)
abline(0, 1, col="#e24b4a", lwd=2)
dev.off()
# 3. Q-Q plot Gamma
png("graf_15_qq_gamma.png", width=700, height=500, res=150)
qgamma_teorico <- qgamma(ppoints(nrow(sev)), shape_gm, rate_gm)
plot(sort(qgamma_teorico), sort(sev$costo_total),
     main="Q-Q plot — Gamma",

xlab="Cuantiles teóricos", ylab="Cuantiles observados",

col="#1D9E75", pch=16, cex=0.7)
abline(0, 1, col="#e24b4a", lwd=2)
dev.off()
# 4. P-P plots comparativos
png("graf_16_pp_comparativo.png", width=1000, height=500, res=150)
par(mfrow=c(1,2))
# Lognormal
pp_ln <- plnorm(sort(sev$costo_total), mu_ln, sigma_ln)
plot(ppoints(nrow(sev)), pp_ln,
     main="P-P plot Lognormal",

xlab="Probabilidad empírica", ylab="Probabilidad teórica",

col="#e24b4a", pch=16, cex=0.7)
abline(0,1, col="black", lwd=2)
# Gamma
pp_gm <- pgamma(sort(sev$costo_total), shape_gm, rate_gm)
plot(ppoints(nrow(sev)), pp_gm,
     main="P-P plot Gamma",

xlab="Probabilidad empírica", ylab="Probabilidad teórica",

col="#1D9E75", pch=16, cex=0.7)
abline(0,1, col="black", lwd=2)
par(mfrow=c(1,1))
dev.off()
# 5. CDF comparativa
p_cdf <- ggplot(sev, aes(x=costo_total)) +
  stat_ecdf(color="#378ADD", linewidth=1.2) +
  stat_function(fun=plnorm, args=list(meanlog=mu_ln, sdlog=sigma_ln),
                color="#e24b4a", linewidth=1, linetype="solid") +
  stat_function(fun=pgamma, args=list(shape=shape_gm, rate=rate_gm),
                color="#1D9E75", linewidth=1, linetype="dashed") +
  scale_x_continuous(labels=scales::comma) +

labs(title="CDF empírica vs ajustadas",
       subtitle="Azul: Empírica | Rojo: Lognormal | Verde: Gamma",
       x="Costo ARS", y="F(x)") +

theme_minimal(base_size=12)
ggsave("graf_17_cdf_comparativa.png", p_cdf, width=8, height=4, dpi=150)
cat("Gráficos guardados: graf_13 a graf_17\n")
# =============================================================================
# H. RESUMEN EJECUTIVO PASO 3
# =============================================================================
cat("\n=== H. RESUMEN EJECUTIVO PASO 3 ===\n")
cat("
DATOS DE SEVERIDAD:
  - N accidentes con costo > 0:", nrow(sev), "

- Media observada:  ARS", format(round(mean(sev$costo_total)), big.mark=","), "
  - Mediana observada: ARS", format(round(median(sev$costo_total)), big.mark=","), "
  - Skewness:        ", round(moments::skewness(sev$costo_total), 4), "
COMPARACIÓN DE MODELOS:
  - Lognormal AIC:", round(fit_ln$aic, 2), "
  - Gamma AIC:    ", round(fit_gm$aic, 2), "

- Modelo seleccionado:", mejor_sev, "
PARÁMETROS LOGNORMAL:

- mu (meanlog):   ", round(mu_ln, 6), "
  - sigma (sdlog):  ", round(sigma_ln, 6), "
PARÁMETROS GAMMA:
  - shape:", round(shape_gm, 6), "
  - rate: ", round(rate_gm, 6), "
VaR DEL MODELO SELECCIONADO:

- P95:", format(round(ifelse(mejor_sev=='LOGNORMAL',
                               qlnorm(0.95, mu_ln, sigma_ln),
                               qgamma(0.95, shape_gm, rate_gm))), big.mark=","), "ARS
  - P99:", format(round(ifelse(mejor_sev=='LOGNORMAL',
                               qlnorm(0.99, mu_ln, sigma_ln),
                               qgamma(0.99, shape_gm, rate_gm))), big.mark=","), "ARS
")
# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Paso 4: Simulación Monte Carlo — Distribución de pérdida agregada
# Prerequisito: correr procesamiento_encuesta_MTB.R + pasos 2 y 3
# =============================================================================
library(tidyverse)
library(ggplot2)
set.seed(42)  # reproducibilidad
# =============================================================================
# A. PARÁMETROS DE ENTRADA
# =============================================================================
cat("=== A. PARÁMETROS DE ENTRADA ===\n")
# Frecuencia — Binomial Negativa
lambda_anual <- 0.3600  # tasa anual base (promedio muestra completa, n=321)
# Nota: usamos la tasa del perfil más común en la muestra
# Severidad — Gamma
mu_sev    <- 12.850  # mu Lognormal (MLE, n=186)
sigma_sev <- 1.428   # sigma Lognormal (MLE, n=186)
# Simulación
N_SIM     <- 100000   # número de simulaciones
N_ASEG    <- 1        # pérdida por asegurado (después escala a cartera)
cat("Parámetros frecuencia (Binomial Negativa):\n")
cat("  Lambda anual:", lambda_anual, "\n")
cat("\nParámetros severidad (Lognormal):\n")
cat("  mu:   ", mu_sev, "\n")
cat("  sigma:", sigma_sev, "\n")
cat("\nSimulaciones:", N_SIM, "\n")
# =============================================================================
# B. SIMULACIÓN MONTE CARLO — PÉRDIDA INDIVIDUAL
# =============================================================================
cat("\n=== B. SIMULACIÓN MONTE CARLO ===\n")
# Para cada simulación:
# 1. Simular número de accidentes N ~ BN(mu=lambda, theta=1.490)
# 2. Para cada accidente, simular costo X_i ~ Gamma(shape, scale)
# 3. Pérdida agregada S = X_1 + X_2 + ...
+ X_N
simular_perdida <- function(n_sim, lambda, mu, sigma) {
  perdidas <- numeric(n_sim)
  for (i in seq_len(n_sim)) {
    n_acc <- rnbinom(1, mu = lambda, size = 1.490)  # BN con theta=1,490
    if (n_acc == 0) {
      perdidas[i] <- 0
    } else {
      perdidas[i] <- sum(rlnorm(n_acc, meanlog=mu, sdlog=sigma))

}
  }
  perdidas
}
cat("Corriendo", N_SIM, "simulaciones...\n")
perdida_sim <- simular_perdida(N_SIM, lambda_anual, mu_sev, sigma_sev)
cat("Simulación completada.\n")
# =============================================================================
# C. ESTADÍSTICAS DE LA DISTRIBUCIÓN SIMULADA
# =============================================================================
cat("\n=== C. DISTRIBUCIÓN DE PÉRDIDA AGREGADA (anual por asegurado) ===\n")
cat("\nEstadísticas:\n")
cat("  Proporción sin siniestro (S=0):", round(mean(perdida_sim == 0)*100, 1), "%\n")
cat("  Media:    ARS", format(round(mean(perdida_sim)), big.mark=","), "\n")
cat("  Mediana:  ARS", format(round(median(perdida_sim)), big.mark=","), "\n")
cat("  Desvío:   ARS", format(round(sd(perdida_sim)), big.mark=","), "\n")
cat("  CV:      ", round(sd(perdida_sim)/mean(perdida_sim), 4), "\n")
cat("\nPercentiles clave:\n")
probs_mc <- c(0.50, 0.75, 0.90, 0.95, 0.99, 0.995)
perc_mc  <- quantile(perdida_sim, probs_mc)
for (i in seq_along(probs_mc)) {
  cat("  P", probs_mc[i]*100, ": ARS",
      format(round(perc_mc[i]), big.mark=","), "\n")
}
# =============================================================================
# D. PRIMA PURA
# =============================================================================
cat("\n=== D. PRIMA PURA ===\n")
prima_pura <- mean(perdida_sim)
cat("Prima pura (E[S]):", format(round(prima_pura), big.mark=","), "ARS/año\n")
cat("Prima pura mensual:", format(round(prima_pura/12), big.mark=","), "ARS/mes\n")
# Tipo de cambio referencial (documentar fecha)
TC <- 1400  # ARS/USD — Dólar blue, Mayo 2026
prima_pura_usd_anual  <- prima_pura / TC
prima_pura_usd_mensual <- prima_pura / TC / 12
cat("\nTipo de cambio referencial: ARS", TC, "/ USD\n")
cat("Prima pura anual:   USD", round(prima_pura_usd_anual, 2), "\n")
cat("Prima pura mensual: USD", round(prima_pura_usd_mensual, 2), "\n")
# =============================================================================
# E. ANÁLISIS DE ESCENARIOS — 2 perfiles simplificados para propuesta comercial
# =============================================================================
cat("\n=== E. PRIMA PURA POR PERFIL COMERCIAL ===\n")
cat("Perfiles simplificados para propuesta de seguro:\n")
cat("  - Recreativo: Princ/Interm, cualquier disciplina (lambda promedio)\n")
cat("  - Competitivo: Avanzado/Experto, cualquier disciplina (lambda promedio)\n\n")
# Lambda promedio por segmento (promedio DH + Enduro de cada nivel)
perfiles_mc <- data.frame(
  perfil      = c("Recreativo (Princ/Interm)", "Competitivo (Avanzado/Experto)"),
  lambda      = c(
    mean(c(0.3163, 0.2371)),   # promedio DH + Enduro para Princ/Interm (escalado a lambda=0.3600)
    mean(c(0.3584, 0.3751, 0.2707, 0.2832))  # promedio DH+Enduro Avanzado+Experto (escalado a lambda=0.3600)
  ),
  descripcion = c(
    "Practica por recreación, sin competencias regulares",
    "Entrena regularmente, participa en competencias"
  )
)
set.seed(42)
perfiles_mc$prima_pura_ars     <- sapply(perfiles_mc$lambda, function(lam) {
  s <- simular_perdida(100000, lam, mu_sev, sigma_sev)

round(mean(s))
})
perfiles_mc$prima_pura_usd_mes <- round(perfiles_mc$prima_pura_ars / TC / 12, 2)
perfiles_mc$p95_ars            <- sapply(perfiles_mc$lambda, function(lam) {
  set.seed(42)
  s <- simular_perdida(100000, lam, mu_sev, sigma_sev)

round(quantile(s, 0.95))
})
cat("Tabla de perfiles comerciales:\n")
print(perfiles_mc[, c("perfil", "lambda", "prima_pura_ars", "prima_pura_usd_mes", "p95_ars")])
# =============================================================================
# F. ANÁLISIS DE SENSIBILIDAD — factor privado
# =============================================================================
cat("\n=== F. SENSIBILIDAD — Factor sector privado ===\n")
factores_priv <- c(1.0, 1.5, 2.0, 2.5)
sens_results  <- data.frame(

factor_privado = factores_priv,
  mu_ajustado = log(exp(mu_sev + sigma_sev^2/2) * (factores_priv * 0.63 + 0.37)) - sigma_sev^2/2,  # ajuste Lognormal
  prima_ars      = NA,
  prima_usd_mes  = NA
)
# Ajuste simple: escalar mu según proporción de casos privados (63%)
for (i in seq_along(factores_priv)) {

f    <- factores_priv[i]
  # mu ajustado: 63% privado con factor f, 37% público sin cambio
  mu_aj <- log(mean(sev$costo_total) * (0.63 * f + 0.37)) +
    # E[X_Gamma] = shape * scale (no requiere corrección por sesgo log-normal)

log(mean(sev$costo_total) * (0.63 * f + 0.37)) * 0

# Más simple: escalar directamente la media y recalcular mu
  media_aj <- mean(sev$costo_total) * (0.63 * f + 0.37)
  mu_aj <- log(media_aj) - sigma_sev^2/2  # ajuste Lognormal: E[X] = exp(mu + sigma^2/2)

  set.seed(42)
  s_aj <- simular_perdida(50000, lambda_anual, mu_sev, mu_aj)

sens_results$prima_ars[i]     <- round(mean(s_aj))
  sens_results$prima_usd_mes[i] <- round(mean(s_aj) / TC / 12, 2)
}
cat("\nPrima pura según factor privado aplicado:\n")
print(sens_results[, c("factor_privado", "prima_ars", "prima_usd_mes")])
# =============================================================================
# G. GRÁFICOS
# =============================================================================
cat("\n=== G. GENERANDO GRÁFICOS ===\n")
# 1. Distribución de pérdida agregada (solo S > 0)
sev_sim <- perdida_sim[perdida_sim > 0]
p_mc <- ggplot(data.frame(s=sev_sim), aes(x=s)) +
  geom_histogram(aes(y=after_stat(density)), bins=40,
                 fill="#378ADD", alpha=0.6, color="white") +
  geom_vline(xintercept=mean(perdida_sim), color="#e24b4a",
             linewidth=1.2, linetype="solid") +
  geom_vline(xintercept=quantile(perdida_sim, 0.95), color="#EF9F27",
             linewidth=1.2, linetype="dashed") +

geom_vline(xintercept=quantile(perdida_sim, 0.99), color="#534AB7",

linewidth=1.2, linetype="dashed") +
  scale_x_continuous(labels=scales::comma) +
  annotate("text", x=mean(perdida_sim)*1.1, y=Inf, vjust=2,

label="Media", color="#e24b4a", size=3.5) +

annotate("text", x=quantile(perdida_sim, 0.95)*1.05, y=Inf, vjust=4,
           label="P95", color="#EF9F27", size=3.5) +

labs(title="Distribución de pérdida agregada anual (Monte Carlo, n=100.000)",
       subtitle="Solo simulaciones con S > 0",
       x="Pérdida ARS", y="Densidad") +

theme_minimal(base_size=12)
ggsave("graf_18_montecarlo_perdida.png", p_mc, width=9, height=4, dpi=150)
# 2. Prima pura por perfil
p_prima <- ggplot(perfiles_mc, aes(x=reorder(perfil, prima_pura_usd_mes),
                                   y=prima_pura_usd_mes, fill=prima_pura_usd_mes)) +

geom_col() +
  scale_fill_gradient(low="#1D9E75", high="#e24b4a") +

coord_flip() +
  labs(title="Prima pura mensual por perfil de ciclista (USD/mes)",
       x="", y="USD/mes", fill="USD/mes") +

theme_minimal(base_size=12)
ggsave("graf_19_prima_por_perfil.png", p_prima, width=8, height=4, dpi=150)
# 3. Sensibilidad factor privado
p_sens <- ggplot(sens_results, aes(x=factor(factor_privado), y=prima_usd_mes)) +
  geom_col(fill="#534AB7", width=0.6) +
  geom_text(aes(label=paste0("USD ", prima_usd_mes)), vjust=-0.5, size=3.5) +

labs(title="Sensibilidad de la prima pura al factor de costo privado",
       x="Factor privado", y="Prima pura mensual (USD)") +

theme_minimal(base_size=12)
ggsave("graf_20_sensibilidad_factor.png", p_sens, width=7, height=4, dpi=150)
cat("Gráficos guardados: graf_18, graf_19, graf_20\n")
# =============================================================================
# H. RESUMEN EJECUTIVO PASO 4
# =============================================================================
cat("\n=== H. RESUMEN EJECUTIVO PASO 4 ===\n")
cat("
SIMULACIÓN MONTE CARLO:
  - N simulaciones:     ", N_SIM, "

- Sin siniestro:     ", round(mean(perdida_sim==0)*100,1), "%
  - Media S:           ARS", format(round(mean(perdida_sim)), big.mark=","), "
  - P95:               ARS", format(round(quantile(perdida_sim,0.95)), big.mark=","), "
  - P99:               ARS", format(round(quantile(perdida_sim,0.99)), big.mark=","), "
PRIMA PURA (perfil base DH Princ/Interm):

- ARS/año:           ", format(round(prima_pura), big.mark=","), "

- USD/mes (TC=", TC, "): ", round(prima_pura/TC/12, 2), "
PRIMA POR PERFIL COMERCIAL:
  - Recreativo:  USD", perfiles_mc$prima_pura_usd_mes[1], "/mes
  - Competitivo: USD", perfiles_mc$prima_pura_usd_mes[2], "/mes
")
# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Paso 5: Bootstrap — estabilidad de estimaciones
# Prerequisito: correr procesamiento_encuesta_MTB.R + pasos 2, 3 y 4
# =============================================================================
library(tidyverse)
library(ggplot2)
set.seed(42)
N_BOOT <- 2000  # iteraciones bootstrap
# =============================================================================
# A. BOOTSTRAP FRECUENCIA — estabilidad de lambda
# =============================================================================
cat("=== A. BOOTSTRAP FRECUENCIA ===\n")
cat("Iteraciones:", N_BOOT, "\n\n")
# Remuestrear con reposición sobre datos_modelo
lambda_boot <- numeric(N_BOOT)
for (b in 1:N_BOOT) {

muestra_b  <- datos_modelo[sample(nrow(datos_modelo), replace=TRUE), ]
  lambda_boot[b] <- mean(muestra_b$n_acc_24m, na.rm=TRUE) / 2  # anualizado
}
cat("--- Lambda (tasa anual) ---\n")
cat("Estimación puntual:  ", round(mean(datos_modelo$n_acc_24m, na.rm=TRUE)/2, 4), "\n")
cat("Media bootstrap:     ", round(mean(lambda_boot), 4), "\n")
cat("Desvío bootstrap:    ", round(sd(lambda_boot), 4), "\n")
cat("IC 95% bootstrap:    [", round(quantile(lambda_boot, 0.025), 4),
    ",", round(quantile(lambda_boot, 0.975), 4), "]\n")
# =============================================================================
# B. BOOTSTRAP SEVERIDAD — estabilidad de shape y scale (Gamma)
# =============================================================================
cat("\n=== B. BOOTSTRAP SEVERIDAD ===\n")
mu_boot    <- numeric(N_BOOT)
sigma_boot <- numeric(N_BOOT)
for (b in 1:N_BOOT) {
  muestra_b   <- sev$costo_total[sample(nrow(sev), replace=TRUE)]

log_muestra <- log(muestra_b)

fit_b         <- fitdist(muestra_b, "lnorm", method = "mle")
  mu_boot[b]    <- fit_b$estimate["meanlog"]; sigma_boot[b] <- fit_b$estimate["sdlog"]
}
cat("--- Parámetros Gamma (shape/scale) ---\n")
cat("\nshape (Gamma, bootstrap):\n")
cat("  Estimación puntual:", round(mu_sev, 4), "\n")
cat("  Media bootstrap:   ", round(mean(mu_boot), 4), "\n")
cat("  Desvío bootstrap:  ", round(sd(mu_boot), 4), "\n")
cat("  IC 95%: [", round(quantile(mu_boot, 0.025), 4),
    ",", round(quantile(mu_boot, 0.975), 4), "]\n")
cat("\nsigma (sdlog):\n")
cat("  Estimación puntual:", round(sigma_ln, 4), "\n")
cat("  Media bootstrap:   ", round(mean(sigma_boot), 4), "\n")
cat("  Desvío bootstrap:  ", round(sd(sigma_boot), 4), "\n")
cat("  IC 95%: [", round(quantile(sigma_boot, 0.025), 4),
    ",", round(quantile(sigma_boot, 0.975), 4), "]\n")
# =============================================================================
# C. BOOTSTRAP PRIMA PURA — intervalo de confianza
# =============================================================================
cat("\n=== C. BOOTSTRAP PRIMA PURA ===\n")
cat("Combinando incertidumbre de frecuencia y severidad...\n")
prima_boot <- numeric(N_BOOT)
for (b in 1:N_BOOT) {

# Remuestrear frecuencia
  muestra_freq <- datos_modelo[sample(nrow(datos_modelo), replace=TRUE), ]

lam_b <- mean(muestra_freq$n_acc_24m, na.rm=TRUE) / 2

  # Remuestrear severidad
  muestra_sev <- sev$costo_total[sample(nrow(sev), replace=TRUE)]
  fit_sev <- fitdist(muestra_sev, "lnorm", method = "mle")
  mu_b    <- fit_sev$estimate["meanlog"]; sigma_b <- fit_sev$estimate["sdlog"]

# Simular pérdida agregada con parámetros remuestreados

n_sim_b <- 10000
  s_b <- numeric(n_sim_b)
  for (i in 1:n_sim_b) {
    n_acc <- rnbinom(1, mu = lam_b, size = 1.490)  # BN con theta fijo
    s_b[i] <- if (n_acc == 0) 0 else sum(rlnorm(n_acc, meanlog = mu_b, sdlog = sigma_b))
  }
  prima_boot[b] <- mean(s_b)
}
prima_boot_usd <- prima_boot / TC / 12
cat("\n--- Prima pura anual (ARS) ---\n")
cat("Estimación puntual: ARS", format(round(prima_pura), big.mark=","), "\n")
cat("Media bootstrap:    ARS", format(round(mean(prima_boot)), big.mark=","), "\n")
cat("Desvío bootstrap:   ARS", format(round(sd(prima_boot)), big.mark=","), "\n")
cat("IC 95% bootstrap:   [ARS", format(round(quantile(prima_boot, 0.025)), big.mark=","),
    ", ARS", format(round(quantile(prima_boot, 0.975)), big.mark=","), "]\n")
cat("\n--- Prima pura mensual (USD, TC=", TC, ") ---\n")
cat("Estimación puntual: USD", round(prima_pura/TC/12, 2), "\n")
cat("Media bootstrap:    USD", round(mean(prima_boot_usd), 2), "\n")
cat("IC 95% bootstrap:   [USD", round(quantile(prima_boot_usd, 0.025), 2),
    ", USD", round(quantile(prima_boot_usd, 0.975), 2), "]\n")
# =============================================================================
# D. BOOTSTRAP COEFICIENTES GLM — estabilidad del modelo de frecuencia
# =============================================================================
cat("\n=== D. BOOTSTRAP COEFICIENTES GLM ===\n")
coef_boot <- matrix(NA, nrow=N_BOOT, ncol=length(coef(mod_bn2)))
colnames(coef_boot) <- names(coef(mod_bn2))
for (b in 1:N_BOOT) {

muestra_b <- datos_modelo[sample(nrow(datos_modelo), replace=TRUE), ]

tryCatch({
    mod_b <- glm(
      n_acc_24m ~ nivel_f2 + disc_f + region_f + tendencia_f +
        anios_practica + compite_f + offset(log_expo),
      family = poisson(link="log"),
      data   = muestra_b
    )
    coef_boot[b, ] <- coef(mod_b)

}, error = function(e) NULL)
}
cat("\n--- IC 95% bootstrap para coeficientes GLM ---\n")
ic_coef <- apply(coef_boot, 2, function(x) {
  x <- x[!is.na(x)]
  c(media=round(mean(x),4), ic_low=round(quantile(x,0.025),4),
    ic_high=round(quantile(x,0.975),4), se=round(sd(x),4))
})
print(t(ic_coef))
# =============================================================================
# E. GRÁFICOS BOOTSTRAP
# =============================================================================
cat("\n=== E. GENERANDO GRÁFICOS ===\n")
# 1. Distribución bootstrap de lambda
p_lam <- ggplot(data.frame(lambda=lambda_boot), aes(x=lambda)) +
  geom_histogram(fill="#378ADD", color="white", bins=40, alpha=0.7) +
  geom_vline(xintercept=mean(datos_modelo$n_acc_24m, na.rm=TRUE)/2,
             color="#e24b4a", linewidth=1.2) +
  geom_vline(xintercept=quantile(lambda_boot, c(0.025, 0.975)),
             color="#EF9F27", linewidth=1, linetype="dashed") +

labs(title="Bootstrap: distribución de lambda (tasa anual)",
       subtitle="Rojo: estimación puntual | Naranja: IC 95%",
       x="Lambda", y="Frecuencia") +
  theme_minimal(base_size=12)
ggsave("graf_21_boot_lambda.png", p_lam, width=7, height=4, dpi=150)
# 2. Distribución bootstrap de mu
p_mu <- ggplot(data.frame(mu=mu_boot), aes(x=mu)) +
  geom_histogram(fill="#1D9E75", color="white", bins=40, alpha=0.7) +
  geom_vline(xintercept=mu_sev, color="#e24b4a", linewidth=1.2) +
  geom_vline(xintercept=quantile(mu_boot, c(0.025, 0.975)),
             color="#EF9F27", linewidth=1, linetype="dashed") +

labs(title="Bootstrap: distribución de shape (Gamma)",
       subtitle="Rojo: estimación puntual | Naranja: IC 95%",
       x="shape (Gamma)", y="Frecuencia") +

theme_minimal(base_size=12)
ggsave("graf_22_boot_shape.png", p_shape, width=7, height=4, dpi=150)
# 3. Distribución bootstrap de prima pura
p_prima_boot <- ggplot(data.frame(prima=prima_boot_usd), aes(x=prima)) +
  geom_histogram(fill="#534AB7", color="white", bins=40, alpha=0.7) +

geom_vline(xintercept=prima_pura/TC/12, color="#e24b4a", linewidth=1.2) +

geom_vline(xintercept=quantile(prima_boot_usd, c(0.025, 0.975)),
             color="#EF9F27", linewidth=1, linetype="dashed") +

labs(title="Bootstrap: distribución de prima pura mensual (USD)",
       subtitle="Rojo: estimación puntual | Naranja: IC 95%",
       x="Prima pura (USD/mes)", y="Frecuencia") +

theme_minimal(base_size=12)
ggsave("graf_23_boot_prima.png", p_prima_boot, width=7, height=4, dpi=150)
cat("Gráficos guardados: graf_21, graf_22, graf_23\n")
# =============================================================================
# F. RESUMEN EJECUTIVO PASO 5
# =============================================================================
cat("\n=== F. RESUMEN EJECUTIVO PASO 5 ===\n")
cat("
BOOTSTRAP (", N_BOOT, "iteraciones):
FRECUENCIA (lambda anual):
  - Estimación puntual:", round(mean(datos_modelo$n_acc_24m,na.rm=TRUE)/2, 4), "
  - IC 95%: [", round(quantile(lambda_boot,0.025),4),

",", round(quantile(lambda_boot,0.975),4), "]
SEVERIDAD (shape Gamma):
  - Estimación puntual mu:", round(mu_sev, 4), "
  - IC 95%: [", round(quantile(mu_boot,0.025),4),
    ",", round(quantile(mu_boot,0.975),4), "]
PRIMA PURA MENSUAL (USD):

- Estimación puntual: USD", round(prima_pura/TC/12, 2), "

- IC 95%: [USD", round(quantile(prima_boot_usd,0.025),2),
    ", USD", round(quantile(prima_boot_usd,0.975),2), "]
  - Amplitud IC: USD", round(diff(quantile(prima_boot_usd,c(0.025,0.975))),2), "
CONCLUSIÓN:
  - Si el IC es angosto (< USD 10): estimaciones estables
  - Si el IC es amplio (> USD 20): alta incertidumbre por n pequeño
")
# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Paso 6: Prima comercial y propuesta de seguro
# Prerequisito: correr procesamiento_encuesta_MTB.R + pasos 2, 3, 4 y 5
# =============================================================================
library(tidyverse)
library(ggplot2)
# =============================================================================
# A. ESTRUCTURA DE LA PRIMA COMERCIAL
# =============================================================================
cat("=== A. ESTRUCTURA DE LA PRIMA COMERCIAL ===\n")
prima_pura_rec  <- perfiles_mc$prima_pura_usd_mes[1]
prima_pura_comp <- perfiles_mc$prima_pura_usd_mes[2]
cat("\nPrima pura base:\n")
cat("  Recreativo:  USD", prima_pura_rec, "/mes\n")
cat("  Competitivo: USD", prima_pura_comp, "/mes\n")
# Recargos para seguro digital de nicho
RECARGO_SEGURIDAD <- 0.15   # 15% — incertidumbre del modelo
RECARGO_GASTOS    <- 0.12   # 12% — distribución digital, sin intermediarios
RECARGO_UTILIDAD  <- 0.08   # 8%  — margen razonable
FACTOR_COMERCIAL  <- (1 + RECARGO_SEGURIDAD) * (1 + RECARGO_GASTOS) * (1 + RECARGO_UTILIDAD)
cat("\nRecargos (seguro digital de nicho):\n")
cat("  Seguridad:", RECARGO_SEGURIDAD*100, "%\n")
cat("  Gastos:   ", RECARGO_GASTOS*100, "%\n")
cat("  Utilidad: ", RECARGO_UTILIDAD*100, "%\n")
cat("  Factor total:", round(FACTOR_COMERCIAL, 4), "\n")
prima_com_rec  <- round(prima_pura_rec  * FACTOR_COMERCIAL, 2)
prima_com_comp <- round(prima_pura_comp * FACTOR_COMERCIAL, 2)
cat("\nPrima comercial mensual:\n")
cat("  Recreativo:  USD", prima_com_rec, "/mes\n")
cat("  Competitivo: USD", prima_com_comp, "/mes\n")
prima_ic_low  <- round(quantile(prima_boot_usd, 0.025) * FACTOR_COMERCIAL, 2)
prima_ic_high <- round(quantile(prima_boot_usd, 0.975) * FACTOR_COMERCIAL, 2)
cat("\nIC 95% bootstrap prima comercial:\n")
cat("  [USD", prima_ic_low, ", USD", prima_ic_high, "]\n")
# =============================================================================
# B. PRIMA COMERCIAL vs WTP
# =============================================================================
cat("\n=== B. PRIMA COMERCIAL vs DISPOSICIÓN A PAGAR ===\n")
wtp_dist <- datos %>%
  filter(!is.na(wtp_monto)) %>%
  mutate(wtp_monto = case_when(
    wtp_monto == "20-Nov" | wtp_monto == "11-20" ~ "11 a 20",
    wtp_monto == "21-30"                         ~ "21 a 30",
    wtp_monto == "31-50"                         ~ "31 a 50",
    wtp_monto == "6-10"                          ~ "6 a 10",
    wtp_monto == "0-5"                           ~ "0 a 5",

wtp_monto == "51+"                           ~ "51 o más",
    TRUE                                         ~ wtp_monto

)) %>%
  count(wtp_monto) %>%
  mutate(
    pct = round(n / sum(n) * 100, 1),
    wtp_medio = case_when(
      wtp_monto == "0 a 5"    ~  2.5,
      wtp_monto == "6 a 10"   ~  8.0,
      wtp_monto == "11 a 20"  ~ 15.5,
      wtp_monto == "21 a 30"  ~ 25.5,
      wtp_monto == "31 a 50"  ~ 40.5,

wtp_monto == "51 o más" ~ 60.0,
      TRUE                    ~ NA_real_

)
  ) %>%
  arrange(wtp_medio)
wtp_prom <- sum(wtp_dist$wtp_medio * wtp_dist$n, na.rm=TRUE) / sum(wtp_dist$n)
mercado_rec <- wtp_dist %>%
  filter(wtp_medio >= prima_com_rec) %>%

summarise(n=sum(n), pct=sum(pct))
cat("\nDistribución WTP:\n")
print(wtp_dist)
cat("\nWTP promedio ponderado: USD", round(wtp_prom, 2), "/mes\n")
cat("Prima comercial recreativo: USD", prima_com_rec, "/mes\n")
cat("Brecha: USD", round(prima_com_rec - wtp_prom, 2), "/mes\n")
cat("\nMercado potencial (WTP >= USD", prima_com_rec, "):",
    mercado_rec$n, "personas (", mercado_rec$pct, "% de la muestra)\n")
# =============================================================================
# C. SENSIBILIDAD A RECARGOS
# =============================================================================
cat("\n=== C. SENSIBILIDAD A RECARGOS ===\n")
escenarios <- expand.grid(
  recargo_seg    = c(0.10, 0.15, 0.20, 0.25),
  recargo_gastos = c(0.10, 0.12, 0.15, 0.20)
) %>%
  mutate(
    factor     = (1 + recargo_seg) * (1 + recargo_gastos) * (1 + RECARGO_UTILIDAD),
    prima_rec  = round(prima_pura_rec  * factor, 2),
    prima_comp = round(prima_pura_comp * factor, 2)
  )
cat("\nPrima recreativo según recargos (USD/mes):\n")
print(escenarios %>%
        dplyr::select(recargo_seg, recargo_gastos, prima_rec) %>%

pivot_wider(names_from=recargo_gastos, values_from=prima_rec,

names_prefix="gastos_"))
# =============================================================================
# D. PROPUESTA DE COBERTURA
# =============================================================================
cat("\n=== D. PROPUESTA DE COBERTURA ===\n")
cobertura <- data.frame(
  Item = c(
    "Atención en guardia de emergencia",
    "Estudios de imagen (Rx, TAC, RMN)",
    "Cirugía traumatológica",
    "Internación (hasta 7 días)",
    "Rehabilitación (hasta 30 sesiones)",
    "Traslado y rescate terrestre",
    "Rescate aéreo (hasta USD 500)",
    "Daños al equipo"
  ),
  Recreativo  = c("Si","Si","Si","Si","Si","Si","No","No"),
  Competitivo = c("Si","Si","Si","Si","Si","Si","Si","No")
)
cat("\nCoberturas por perfil:\n")
print(cobertura)
cat("\nPreferencia de cobertura (encuesta):\n")
print(table(datos$tipo_cobertura))
# =============================================================================
# E. VIABILIDAD Y CONCLUSIÓN
# =============================================================================
cat("\n=== E. ANÁLISIS DE VIABILIDAD ===\n")
N_POTENCIAL <- 15000
penetracion  <- mercado_rec$pct / 100 * 0.5
n_aseg       <- round(N_POTENCIAL * penetracion)
ingreso_anual <- round(n_aseg * prima_com_rec * 12)
cat("\nMercado potencial estimado:", N_POTENCIAL, "ciclistas DH+Enduro en Argentina\n")
cat("Penetración esperada (50% de quienes pagarían):", round(penetracion*100,1), "%\n")
cat("Asegurados estimados:", n_aseg, "\n")
cat("Ingreso anual estimado: USD", format(ingreso_anual, big.mark=","), "\n")
cat("\n=== CONCLUSIÓN FINAL ===\n")
cat("
HALLAZGOS CLAVE:
1. Prima pura: USD", prima_pura_rec, "/mes (recreativo) —",
    prima_pura_comp, "/mes (competitivo)

IC 95% bootstrap: [USD", round(quantile(prima_boot_usd,0.025),2),
    ", USD", round(quantile(prima_boot_usd,0.975),2), "]
2. Prima comercial mínima: USD", prima_com_rec, "/mes (recreativo)
   Supera el WTP promedio (USD", round(wtp_prom,2), "/mes) en USD",

round(prima_com_rec - wtp_prom, 2), "/mes
3. Mercado viable: el", mercado_rec$pct, "% de la muestra (ciclistas
   competitivos de mayor WTP) representa el segmento inicial.
4. Viabilidad condicionada a:
   - Distribución digital para reducir gastos
   - Alianzas con federaciones (AMTB, UCAM) para economías de escala
   - Posible subsidio cruzado o convenios con prestadores médicos
5. Con n=", n_aseg, "asegurados el ingreso anual sería USD",
    format(ingreso_anual, big.mark=","), "— escala mínima viable
   para un producto de seguro deportivo de nicho.
")
# =============================================================================
# F. GRÁFICOS
# =============================================================================
cat("\n=== F. GENERANDO GRÁFICOS ===\n")
# 1. WTP vs prima comercial
wtp_plot <- wtp_dist %>% filter(!is.na(wtp_medio))
p_wtp <- ggplot(wtp_plot, aes(x=reorder(wtp_monto, wtp_medio), y=n)) +
  geom_col(aes(fill = wtp_medio >= prima_com_rec), width=0.7) +

scale_fill_manual(values=c("#d0d0d0","#1D9E75"),
                    labels=c("Por debajo de prima","Dispuesto a pagar")) +

annotate("text", x=4.5, y=max(wtp_plot$n)*0.85,

label=paste0("Prima recreativo\nUSD ", prima_com_rec, "/mes"),
           color="#e24b4a", size=3.5) +
  labs(title="Disposición a pagar vs prima comercial estimada",
       x="WTP (USD/mes)", y="N° respondentes", fill="") +

theme_minimal(base_size=12) +
  theme(legend.position="bottom")
ggsave("graf_24_wtp_vs_prima.png", p_wtp, width=8, height=4, dpi=150)
# 2. Estructura de la prima
estructura <- data.frame(
  componente = c("Prima pura", "Recargo seguridad", "Gastos admin.", "Utilidad"),
  valor = c(
    prima_pura_rec,
    prima_pura_rec * RECARGO_SEGURIDAD,
    prima_pura_rec * (1 + RECARGO_SEGURIDAD) * RECARGO_GASTOS,
    prima_pura_rec * (1 + RECARGO_SEGURIDAD) * (1 + RECARGO_GASTOS) * RECARGO_UTILIDAD
  )
)
estructura$pct <- round(estructura$valor / sum(estructura$valor) * 100, 1)
p_estr <- ggplot(estructura, aes(x=reorder(componente, valor), y=valor, fill=componente)) +

geom_col(width=0.6) +
  scale_fill_manual(values=c("#378ADD","#e24b4a","#EF9F27","#1D9E75")) +
  geom_text(aes(label=paste0("USD ", round(valor,1), " (", pct, "%)")),
            hjust=-0.1, size=3.5) +
  coord_flip() +
  expand_limits(y=prima_com_rec * 1.3) +

labs(title=paste0("Estructura prima comercial recreativo — USD ", prima_com_rec, "/mes"),
       x="", y="USD/mes", fill="") +

theme_minimal(base_size=12) +
  theme(legend.position="none")
ggsave("graf_25_estructura_prima.png", p_estr, width=8, height=4, dpi=150)
# 3. Sensibilidad recargos
p_sens <- escenarios %>%
  mutate(gastos_label = paste0("Gastos ", recargo_gastos*100, "%")) %>%
  ggplot(aes(x=factor(recargo_seg*100), y=prima_rec,
             group=gastos_label, color=gastos_label)) +

geom_line(linewidth=1.2) +
  geom_point(size=3) +
  geom_hline(yintercept=wtp_prom, linetype="dashed", color="#888780") +
  annotate("text", x=0.6, y=wtp_prom+0.8,
           label=paste0("WTP promedio USD ", round(wtp_prom,1)),

color="#888780", size=3.2) +
  labs(title="Sensibilidad de prima recreativo a recargos (USD/mes)",
       x="Recargo seguridad (%)", y="Prima USD/mes", color="") +

theme_minimal(base_size=12)
ggsave("graf_26_sensibilidad_recargos.png", p_sens, width=8, height=4, dpi=150)
cat("Graficos guardados: graf_24, graf_25, graf_26\n")
# =============================================================================
# G. RESUMEN EJECUTIVO PASO 6
# =============================================================================
cat("\n=== G. RESUMEN EJECUTIVO PASO 6 ===\n")
cat("
PRIMA PURA:
  - Recreativo:  USD", prima_pura_rec, "/mes
  - Competitivo: USD", prima_pura_comp, "/mes
PRIMA COMERCIAL (recargos 15%+12%+8% = factor", round(FACTOR_COMERCIAL,3), "):
  - Recreativo:  USD", prima_com_rec, "/mes
  - Competitivo: USD", prima_com_comp, "/mes

- IC 95%: [USD", prima_ic_low, ", USD", prima_ic_high, "]
WTP:
  - Promedio ponderado: USD", round(wtp_prom, 2), "/mes
  - Brecha vs prima recreativo: USD", round(prima_com_rec - wtp_prom, 2), "/mes
  - Mercado potencial: ", mercado_rec$pct, "% de la muestra
CONCLUSIÓN:
  Prima técnicamente necesaria supera WTP promedio.
  Producto viable para segmento competitivo (", mercado_rec$pct, "% muestra).
  Requiere distribución digital y alianzas para reducir costos.
")
# =============================================================================
# TESINA: Evaluación actuarial del riesgo en ciclismo de montaña
# Carrera de Actuario - FCE-UBA | Ana Laura Petcoff
# Script: Limpieza, ISC y costos por accidente
# Fuente aranceles: Nomenclador MS-GCABA - Vigente 15 Abril 2026
# =============================================================================
library(tidyverse)
library(janitor)
# =============================================================================
# 0. ARANCELES DE REFERENCIA (Nomenclador MS-GCABA, Abril 2026)
# =============================================================================
ARANCEL_GUARDIA        <- 132226   # GUAR.02: observación en guardia
ARANCEL_DIA_INTERNAC   <- 444959   # INC.01: día clínico
ARANCEL_CIRUGIA_OST    <- 1473726  # OYT.04.10: osteosíntesis miembro sup/inf
ARANCEL_CIRUGIA_ART    <- 654955   # OYT.09.01: artroscopia (luxaciones)
ARANCEL_CIRUGIA_DISC   <- 2120812  # OYT.05.04: hernia discal / cadera
ARANCEL_RX             <- 16637    # IMA.20: radiografía simple
ARANCEL_ECOGRAFIA      <- 22183    # IMA.12: ecografía simple
ARANCEL_TAC            <- 159121   # IMA.22: tomografía computada
ARANCEL_RMN            <- 190602   # IMA.21: resonancia magnética
ARANCEL_SESION_REHAB   <- 21610    # REHA.06: kinesioterapia por sesión
FACTOR_PUBLICO         <- 1.0      # nomenclador GCBA
FACTOR_PRIVADO         <- 1.0      # mismo arancel base GCBA (ver análisis de sensibilidad en tesina)
N_ACC <- 7
# =============================================================================
# 1. CARGA
# =============================================================================
datos_raw <- read_csv("respuestas_xlsx.csv", show_col_types = FALSE)
datos <- clean_names(datos_raw)
# Nota: clean_names() resuelve columnas duplicadas agregando el número de columna.
# lesion_principal queda: _18 (acc1), _31 (acc2), _2 (acc3), _3..._6 (acc4-7)
# =============================================================================
# 2. RENOMBRAR
# =============================================================================
datos <- datos %>% rename(
  edad                 = edad_indicar_numero,
  region               = region_donde_mas_practicas_la_disciplina,
  otro_pais            = si_selecciono_otro_pais_especifique_cual,
  disciplina_principal = cual_es_tu_disciplina_principal_de_ciclismo,
  otras_disciplinas    = practicas_otras_disciplinas_ademas_de_la_principal,
  nivel                = como_describirias_tu_nivel_en_la_disciplina_principal,
  anios_practica       = hace_cuantos_anos_practicas_la_disciplina_principal,
  meses_anio           = cuantos_meses_al_ano_practicas_la_disciplina_principal,
  dias_semana          = cuantos_dias_por_semana_practicas_la_disciplina_principal_en_esos_meses,
  horas_dia            = cuantas_horas_dedicas_a_la_disciplina_principal_en_un_dia_tipico_de_salida,
  tendencia_exposicion = comparada_con_tus_primeros_anos_de_practica_como_fue_tu_intensidad_frecuencia_horas_a_lo_largo_del_tiempo,
  compite              = participas_en_competencias,
  competencias_anio    = cuantas_competencias_en_promedio_por_ano_indicar_numero,
  tuvo_lesiones        = tuviste_lesiones_que_requerian_asistencia_medica_en_los_ultimos_24_meses,
  n_acc_24m            = cuantas_lesiones_que_requerian_asistencia_medica_tuviste_en_los_ultimos_24_meses_indicar_numero,
  cobertura            = tenes_cobertura_medica,
  cobertura_deportes   = tu_cobertura_incluye_accidentes_deportivos,
  contrataria_seguro   = contratarias_un_seguro_deportivo_especifico_para_ciclismo,
  wtp_monto            = cuanto_pagarias_usd_mes_por_este_seguro_deportivo,
  tipo_cobertura       = que_tipo_de_cobertura_preferirias
)
# Accidente 1
datos <- datos %>% rename(
  acc1_disc          = disciplina,
  acc1_lesion        = lesion_principal_18,
  acc1_parte         = parte_del_cuerpo,
  acc1_contexto      = contexto,
  acc1_guardia       = requirio_guardia_o_emergencia,
  acc1_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias,
  acc1_cirugia       = requirio_cirugia,
  acc1_imagen        = estudios_de_imagen,
  acc1_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron,
  acc1_evacuacion    = evacuacion,
  acc1_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc,
  acc1_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional,
  acc1_lugar         = donde_recibiste_atencion_medica_por_este_accidente
)
# Accidente 2
datos <- datos %>% rename(
  acc2_tiene         = tenes_un_segundo_accidente_para_registrar,
  acc2_disc          = disciplina_2,
  acc2_lesion        = lesion_principal_31,
  acc2_parte         = parte_del_cuerpo_2,
  acc2_contexto      = contexto_2,
  acc2_guardia       = requirio_guardia_o_emergencia_2,
  acc2_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_2,
  acc2_cirugia       = requirio_cirugia_2,
  acc2_imagen        = estudios_de_imagen_2,
  acc2_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_2,
  acc2_evacuacion    = evacuacion_2,
  acc2_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_2,
  acc2_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_2,
  acc2_lugar         = donde_recibiste_atencion_medica_por_este_accidente_2
)
# Accidente 3
datos <- datos %>% rename(
  acc3_tiene         = tenes_un_tercer_accidente_para_registrar,
  acc3_disc          = disciplina_3,
  acc3_lesion        = lesion_principal_2,
  acc3_parte         = parte_del_cuerpo_3,
  acc3_contexto      = contexto_3,
  acc3_guardia       = requirio_guardia_o_emergencia_3,
  acc3_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_3,
  acc3_cirugia       = requirio_cirugia_3,
  acc3_imagen        = estudios_de_imagen_3,
  acc3_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_3,
  acc3_evacuacion    = evacuacion_3,
  acc3_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_3,
  acc3_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_3,
  acc3_lugar         = donde_recibiste_atencion_medica_por_este_accidente_3
)
# Accidente 4
datos <- datos %>% rename(
  acc4_tiene         = tenes_un_cuarto_accidente_para_registrar,
  acc4_disc          = disciplina_4,
  acc4_lesion        = lesion_principal_3,
  acc4_parte         = parte_del_cuerpo_4,
  acc4_contexto      = contexto_4,
  acc4_guardia       = requirio_guardia_o_emergencia_4,
  acc4_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_4,
  acc4_cirugia       = requirio_cirugia_4,
  acc4_imagen        = estudios_de_imagen_4,
  acc4_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_4,
  acc4_evacuacion    = evacuacion_4,
  acc4_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_4,
  acc4_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_4,
  acc4_lugar         = donde_recibiste_atencion_medica_por_este_accidente_4
)
# Accidente 5
datos <- datos %>% rename(
  acc5_tiene         = tenes_un_quinto_accidente_para_registrar,
  acc5_disc          = disciplina_5,
  acc5_lesion        = lesion_principal_4,
  acc5_parte         = parte_del_cuerpo_5,
  acc5_contexto      = contexto_5,
  acc5_guardia       = requirio_guardia_o_emergencia_5,
  acc5_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_5,
  acc5_cirugia       = requirio_cirugia_5,
  acc5_imagen        = estudios_de_imagen_5,
  acc5_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_5,
  acc5_evacuacion    = evacuacion_5,
  acc5_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_5,
  acc5_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_5,
  acc5_lugar         = donde_recibiste_atencion_medica_por_este_accidente_5
)
# Accidente 6
datos <- datos %>% rename(
  acc6_tiene         = tenes_un_sexto_accidente_para_registrar,
  acc6_disc          = disciplina_6,
  acc6_lesion        = lesion_principal_5,
  acc6_parte         = parte_del_cuerpo_6,
  acc6_contexto      = contexto_6,
  acc6_guardia       = requirio_guardia_o_emergencia_6,
  acc6_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_6,
  acc6_cirugia       = requirio_cirugia_6,
  acc6_imagen        = estudios_de_imagen_6,
  acc6_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_6,
  acc6_evacuacion    = evacuacion_6,
  acc6_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_6,
  acc6_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_6,
  acc6_lugar         = donde_recibiste_atencion_medica_por_este_accidente_6
)
# Accidente 7
datos <- datos %>% rename(
  acc7_tiene         = tenes_un_septimo_accidente_para_registrar,
  acc7_disc          = disciplina_7,
  acc7_lesion        = lesion_principal_6,
  acc7_parte         = parte_del_cuerpo_7,
  acc7_contexto      = contexto_7,
  acc7_guardia       = requirio_guardia_o_emergencia_7,
  acc7_internacion   = en_caso_de_requerir_internacion_por_cuantos_dias_7,
  acc7_cirugia       = requirio_cirugia_7,
  acc7_imagen        = estudios_de_imagen_7,
  acc7_rehab         = si_realizaste_rehabilitacion_profesional_kinesiologia_fisioterapia_u_otra_cuantas_sesiones_fueron_7,
  acc7_evacuacion    = evacuacion_7,
  acc7_dias_perdidos = dias_de_actividad_perdidos_trabajo_escuela_universidad_etc_7,
  acc7_descripcion   = queres_contar_algo_mas_sobre_este_accidente_opcional_7,
  acc7_lugar         = donde_recibiste_atencion_medica_por_este_accidente_7
)
# Eliminar columnas fantasma
datos <- datos %>% dplyr::select(-matches("^parte_del_cuerpo_(8|9|10|11|12|13)$"))
# =============================================================================
# 3. LIMPIEZA
# =============================================================================
datos <- datos %>%
  mutate(fecha = Sys.Date())
rehab_cols    <- paste0("acc", 1:N_ACC, "_rehab")
dias_cols     <- paste0("acc", 1:N_ACC, "_dias_perdidos")
internac_cols <- paste0("acc", 1:N_ACC, "_internacion")
datos <- datos %>%

mutate(across(all_of(rehab_cols),    ~ replace_na(as.numeric(.x), 0))) %>%
  mutate(across(all_of(dias_cols),     ~ replace_na(as.numeric(.x), 0))) %>%
  mutate(across(all_of(internac_cols), ~ replace_na(as.numeric(.x), 0))) %>%

mutate(n_acc_24m = if_else(tuvo_lesiones == "No", 0, as.numeric(n_acc_24m)))
# =============================================================================
# 4. FILTROS DE MUESTRA
# =============================================================================
# 1. Solo Argentina
# 2. Solo DH o Enduro como disciplina principal O secundaria
# 3. n_acc_24m <= 7 (el formulario solo captura hasta 7 accidentes;
#    quien declara 9 probablemente incluyó accidentes sin atención médica
#    o errores de tipeo — se documenta como criterio de exclusión)
datos <- datos %>%
  filter(region != "Otro país") %>%
  filter(
    str_detect(disciplina_principal, "Downhill|DH|Enduro") |
      str_detect(otras_disciplinas,    "Downhill|DH|Enduro")

) %>%
  filter(is.na(n_acc_24m) | n_acc_24m <= 7)
cat("Respondentes tras filtros:", nrow(datos), "\n")
# =============================================================================
# 5. EXPOSICIÓN (ventana 24 meses)
# =============================================================================
datos <- datos %>%
  mutate(
    # Para menos de 1 año: meses calculados desde anios_practica directamente
    # Para el resto: usa meses_anio reportado
    meses_efectivos  = if_else(anios_practica < 1,
                               anios_practica * 12,
                               as.numeric(meses_anio)),
    # Ventana máxima: 2 años (24 meses)
    anos_exposicion  = pmin(anios_practica, 2),
    # tendencia_exposicion entra como covariable en el GLM
    exposicion_horas = anos_exposicion * (meses_efectivos / 12) * dias_semana * horas_dia * 52.18
  )
# Excluir outliers de exposición (>5000h en 24m = implausible)
# Criterio documentado en tesina como criterio de calidad de datos
n_antes <- nrow(datos)
datos <- datos %>% filter(exposicion_horas <= 5000)
cat("Outliers de exposicion excluidos:", n_antes - nrow(datos), "\n")
cat("Respondentes finales:", nrow(datos), "\n")
# =============================================================================
# 6. FUNCIONES: COSTO E ISC
# =============================================================================
factor_lugar <- function(lugar) {

case_when(
    is.na(lugar)                                 ~ FACTOR_PUBLICO,

str_detect(lugar, "blico|público")           ~ FACTOR_PUBLICO,
    str_detect(lugar, "privado|clínica|clinica") ~ FACTOR_PRIVADO,

TRUE                                         ~ FACTOR_PUBLICO
  )
}
costo_imagen <- function(imagen) {
  case_when(

is.na(imagen)                       ~ 0,
    str_detect(imagen, "Ninguno")       ~ 0,
    str_detect(imagen, "Radiograf")     ~ ARANCEL_RX,
    str_detect(imagen, "Ecograf")       ~ ARANCEL_ECOGRAFIA,
    str_detect(imagen, "TAC|Tomograf")  ~ ARANCEL_TAC,
    str_detect(imagen, "Resonan|RMN")   ~ ARANCEL_RMN,
    TRUE                                ~ ARANCEL_RX
  )
}
# Cirugía diferenciada por lesión y parte del cuerpo
# OYT.09.01 artroscopia / OYT.05.04 cadera-espalda / OYT.04.10 osteosíntesis
costo_cirugia <- function(cirugia, lesion, parte) {

case_when(
    is.na(cirugia) | cirugia == "No"   ~ 0,

str_detect(parte,  "Espalda")      ~ ARANCEL_CIRUGIA_DISC,
    str_detect(parte,  "Cadera|pelvis")~ ARANCEL_CIRUGIA_DISC,

str_detect(lesion, "Luxaci")       ~ ARANCEL_CIRUGIA_ART,
    TRUE                               ~ ARANCEL_CIRUGIA_OST

)
}
calcular_ISC <- function(guardia, internacion, cirugia, lesion, parte, imagen, rehab, evacuacion) {

pts_guardia  <- if_else(!is.na(guardia) & str_detect(guardia, "^S[ií]"), 1, 0)
  pts_cirugia  <- if_else(!is.na(cirugia) & str_detect(cirugia, "^S[ií]"), 5, 0)

pts_internac <- case_when(
    is.na(internacion) | internacion == 0 ~ 0,
    internacion <= 3                      ~ 2,
    internacion <= 7                      ~ 4,
    internacion > 7                       ~ 7,
    TRUE                                  ~ 0
  )

  # pts_imagen: suma aditiva por tipo de estudio (corregido: case_when solo captura el primero)

pts_imagen <- if_else(is.na(imagen) | str_detect(imagen, "Ninguno"), 0L,
                        as.integer(str_detect(imagen, "Radiograf")) * 1L +
                          as.integer(str_detect(imagen, "Ecograf"))  * 2L +
                          as.integer(str_detect(imagen, "TAC|Tomograf")) * 2L +
                          as.integer(str_detect(imagen, "Resonan|RMN")) * 3L
  )

  pts_rehab <- case_when(
    is.na(rehab) | rehab == 0 ~ 0,
    rehab < 4                 ~ 1,
    rehab <= 12               ~ 2,
    rehab > 12                ~ 4,
    TRUE                      ~ 0
  )

  pts_evacuacion <- case_when(
    is.na(evacuacion)                             ~ 0,
    str_detect(evacuacion, "Autoe|compa")         ~ 0,
    str_detect(evacuacion, "terrestre|Rescate t") ~ 2,
    str_detect(evacuacion, "éreo|aereo|aéreo")    ~ 5,

TRUE                                          ~ 0
  )

  pts_guardia + pts_internac + pts_cirugia + pts_imagen + pts_rehab + pts_evacuacion
}
# =============================================================================
# 7. CALCULAR ISC Y COSTO POR ACCIDENTE
# =============================================================================
for (i in 1:N_ACC) {
  g   <- paste0("acc", i, "_guardia")

int <- paste0("acc", i, "_internacion")
  cir <- paste0("acc", i, "_cirugia")
  les <- paste0("acc", i, "_lesion")
  par <- paste0("acc", i, "_parte")

img <- paste0("acc", i, "_imagen")
  reh <- paste0("acc", i, "_rehab")

eva <- paste0("acc", i, "_evacuacion")
  lug <- paste0("acc", i, "_lugar")

  fl <- factor_lugar(datos[[lug]])

  datos[[paste0("acc", i, "_ISC")]] <- calcular_ISC(
    datos[[g]], datos[[int]], datos[[cir]], datos[[les]],
    datos[[par]], datos[[img]], datos[[reh]], datos[[eva]]
  )

  datos[[paste0("acc", i, "_costo_guardia")]] <-

if_else(!is.na(datos[[g]]) & str_detect(datos[[g]], "^S[ií]"),

ARANCEL_GUARDIA * fl, 0)

  datos[[paste0("acc", i, "_costo_cirugia")]] <-
    costo_cirugia(datos[[cir]], datos[[les]], datos[[par]]) * fl

  datos[[paste0("acc", i, "_costo_internac")]] <-
    if_else(is.na(datos[[int]]) | datos[[int]] == 0, 0,
            datos[[int]] * ARANCEL_DIA_INTERNAC * fl)

  datos[[paste0("acc", i, "_costo_imagen")]] <- costo_imagen(datos[[img]]) * fl
  datos[[paste0("acc", i, "_costo_rehab")]]  <- datos[[reh]] * ARANCEL_SESION_REHAB * fl

  datos[[paste0("acc", i, "_costo_total")]] <-
    datos[[paste0("acc", i, "_costo_guardia")]]  +
    datos[[paste0("acc", i, "_costo_internac")]] +
    datos[[paste0("acc", i, "_costo_cirugia")]]  +
    datos[[paste0("acc", i, "_costo_imagen")]]   +
    datos[[paste0("acc", i, "_costo_rehab")]]
}
# Totales por persona
isc_cols   <- paste0("acc", 1:N_ACC, "_ISC")
costo_cols <- paste0("acc", 1:N_ACC, "_costo_total")
datos <- datos %>%
  mutate(
    ISC_max         = pmax(!!!syms(isc_cols),   na.rm = TRUE),
    costo_total_24m = rowSums(across(all_of(costo_cols)), na.rm = TRUE)

)
# =============================================================================
# 8. WTP — normalizar formato y calcular punto medio
# =============================================================================
datos <- datos %>%
  mutate(wtp_monto = case_when(
    wtp_monto == "20-Nov" | wtp_monto == "11-20" ~ "11 a 20",
    wtp_monto == "21-30"                         ~ "21 a 30",
    wtp_monto == "31-50"                         ~ "31 a 50",
    wtp_monto == "6-10"                          ~ "6 a 10",
    wtp_monto == "0-5"                           ~ "0 a 5",

wtp_monto == "51+"                           ~ "51 o más",
    TRUE                                         ~ wtp_monto

)) %>%
  mutate(wtp_medio = case_when(
    wtp_monto == "0 a 5"    ~  2.5,
    wtp_monto == "6 a 10"   ~  8.0,
    wtp_monto == "11 a 20"  ~ 15.5,
    wtp_monto == "21 a 30"  ~ 25.5,

wtp_monto == "31 a 50"  ~ 40.5,
    wtp_monto == "51 o más" ~ 60.0,
    TRUE                    ~ NA_real_
  ))
# =============================================================================
# 9. FORMATO LARGO: un accidente por fila (para GLM)
# =============================================================================
acc_largo <- datos %>%
  dplyr::select(timestamp, edad, genero, region, disciplina_principal, nivel,
                tendencia_exposicion, anios_practica, exposicion_horas, n_acc_24m,

matches("^acc[1-7]_")) %>%
  pivot_longer(
    cols          = matches("^acc[1-7]_"),
    names_to      = c("acc_num", ".value"),
    names_pattern = "acc([1-7])_(.*)"
  ) %>%
  filter(!is.na(disc)) %>%
  mutate(acc_num = as.integer(acc_num))
# =============================================================================
# 10. EXPORTAR
# =============================================================================
write_csv(datos,     "datos_wide.csv")
write_csv(acc_largo, "datos_largo.csv")
cat("\nProcesamiento completo\n")
cat("  Respondentes:          ", nrow(datos), "\n")
cat("  Accidentes registrados:", nrow(acc_largo), "\n")
# =============================================================================
# 11. RESUMEN
# =============================================================================
cat("\n--- Exposicion 24m (horas) ---\n")
print(summary(datos$exposicion_horas))
cat("\n--- n_acc_24m ---\n")
print(table(datos$n_acc_24m, useNA = "ifany"))
cat("\n--- ISC maximo por persona ---\n")
print(summary(datos$ISC_max))
cat("\n--- Costo total 24m (ARS) ---\n")
print(summary(datos$costo_total_24m))
cat("\n--- WTP (USD/mes) ---\n")
print(table(datos$wtp_monto, useNA = "ifany"))
cat("\n--- Verificacion outliers n_acc ---\n")
datos %>%
  filter(n_acc_24m >= 6) %>%
  dplyr::select(edad, nivel, disciplina_principal, anios_practica,
                exposicion_horas, n_acc_24m, compite) %>%
  print()
# =============================================================================
# 12. ANÁLISIS DE SENSIBILIDAD — Factor privado
# =============================================================================
# El nomenclador GCBA se usa como base única (FACTOR_PRIVADO = 1.0).
# Este bloque evalúa el impacto de distintos factores sobre los casos privados.
# Fuente limitación: no existe nomenclador público para el sector privado en AR.
cat("\n=== ANÁLISIS DE SENSIBILIDAD — Factor privado ===\n")
factores <- c(1.0, 1.5, 2.0, 2.5)
# Identificar casos con atención privada en accidente 1
privado_mask <- !is.na(datos$acc1_lugar) &
  str_detect(datos$acc1_lugar, "privado|clínica|clinica")
resultados_sens <- sapply(factores, function(f) {

costo_ajustado <- datos$costo_total_24m
  # Aplicar factor solo a los casos privados
  costo_ajustado[privado_mask] <- costo_ajustado[privado_mask] * f
  c(
    media   = round(mean(costo_ajustado, na.rm=TRUE)),
    mediana = round(median(costo_ajustado, na.rm=TRUE)),
    p95     = round(quantile(costo_ajustado, 0.95, na.rm=TRUE))
  )
})
colnames(resultados_sens) <- paste0("Factor_", factores)
cat("\nCosto total 24m (ARS) según factor privado aplicado:\n")
print(resultados_sens)
cat("\nNota: Factor 1.0 = nomenclador GCBA para todos (base)\n")
cat("      Factor 2.5 = estimación conservadora sector privado libre\n")